﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConectorSap;
using SAPbobsCOM;
namespace GuardaStock
{
    
    internal class Program
    {
        private Conector oSociedad;
        public static void Main(string[] args)
        {
            Program pr = new Program();
            //string fecha = DateTime.Now.ToString("yyyy-MM-dd");
            //Console.WriteLine($"La fecha actual es {fecha}");
            pr.conectar();
            //pr.conectar2();prueba3
            pr.recuperar();
            pr.desconecta();
            

        }
        public void conectar() 
        {
            int iCodigoError;
            try
            {
                oSociedad = new Conector();

                iCodigoError = oSociedad.ConectarDI(ConfigurationManager.AppSettings["TipoServidor"],
                    ConfigurationManager.AppSettings["Servidor"],
                    ConfigurationManager.AppSettings["ServidorSLD"],
                    ConfigurationManager.AppSettings["ServidorLicencia"],
                    ConfigurationManager.AppSettings["BaseDatos"],
                    ConfigurationManager.AppSettings["UsuarioSAP"],
                    ConfigurationManager.AppSettings["PasswordSAP"],
                    ConfigurationManager.AppSettings["UsuarioBD"],
                    ConfigurationManager.AppSettings["PasswordBD"]);

                if (iCodigoError != 0)
                {
                    Console.WriteLine($"Ocurrio un error de conexion {oSociedad.RecuperrarErrorSBO()}");
                    return;
                }
                else
                {
                    Console.WriteLine($"Conexion Exitosa a Productivo ");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{Environment.NewLine} Error de conexion {ex.Message}");
                return;
            }
        }
        public void conectar2() 
        {
            int iCodigoError;
            try
            {
                

                iCodigoError = oSociedad.ConectarPruebas(ConfigurationManager.AppSettings["TipoServidor"],
                    ConfigurationManager.AppSettings["Servidor"],
                    ConfigurationManager.AppSettings["ServidorSLD"],
                    ConfigurationManager.AppSettings["ServidorLicencia"],
                    ConfigurationManager.AppSettings["BaseDatos"],
                    ConfigurationManager.AppSettings["UsuarioSAP"],
                    ConfigurationManager.AppSettings["PasswordSAP"],
                    ConfigurationManager.AppSettings["UsuarioBD"],
                    ConfigurationManager.AppSettings["PasswordBD"]);

                if (iCodigoError != 0)
                {
                    Console.WriteLine($"Ocurrio un error de conexion {oSociedad.RecuperrarErrorSBOPruebas()}");
                    return;
                }
                else
                {
                    Console.WriteLine($"Conexion Exitosa a PRUEBA3 ");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{Environment.NewLine} Error de conexion {ex.Message}");
                return;
            }
        }
        public void desconecta() 
        {
            try
            {
                oSociedad.DesconectarDI();
                Console.WriteLine($"{Environment.NewLine} Desconexion exitosa");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{Environment.NewLine} Error al desconectar {ex.Message}");

            }
        }
        public void recuperar() 
        {
            string sConsulta;

            //sConsulta = "SELECT T0.ItemCode,T1.OnHand,T0.ItmsGrpCod,T1.AvgPrice FROM OITM T0 LEFT OUTER JOIN OITW T1 ON T1.ItemCode=T0.ItemCode WHERE T0.ItmsGrpCod!='101' AND T0.ItmsGrpCod!='106' AND T1.WhsCode='01' AND T1.AvgPrice!=0 ";
            sConsulta = "SELECT T0.ItemCode,ISNULL((SELECT (SUM(Y.InQty)-SUM(Y.OutQty)) FROM OINM Y WHERE Y.ItemCode = T0.ItemCode AND Y.Warehouse!='100' AND Y.Warehouse!='110' " +
               "AND Y.DocDate<='2023-10-10'),0)AS 'OnHand',T0.ItmsGrpCod,T1.AvgPrice FROM OITM T0 LEFT OUTER JOIN OITW T1 ON T1.ItemCode=T0.ItemCode WHERE T0.ItmsGrpCod!='101' AND T0.ItmsGrpCod!='106' AND T1.WhsCode='01' AND T1.AvgPrice!=0 ";//Un dia menos al actual
            //sConsulta = "SELECT T0.ItemCode,(SELECT SUM(Y.OnHand) FROM OITW Y WHERE Y.ItemCode = T0.ItemCode AND Y.WhsCode!='100' AND Y.WhsCode!='110') AS 'OnHand',T0.ItmsGrpCod,T1.AvgPrice FROM OITM T0 LEFT OUTER JOIN OITW T1 ON T1.ItemCode=T0.ItemCode WHERE T0.ItmsGrpCod!='101' AND T0.ItmsGrpCod!='106' AND T1.WhsCode='01' AND T1.AvgPrice!=0 ";
            SAPbobsCOM.Recordset sboResultado;
            string sError;
            sboResultado = oSociedad.GeneraConsulta(sConsulta, out sError);
            if (sError != string.Empty)
            {
                Console.WriteLine($"{Environment.NewLine} Error al Buscar {sError}");
            }

            int icodigoerror;
            string codigo; double stock; int grupoart; double costo;
            for (int iIndiceFila = 0; iIndiceFila < sboResultado.RecordCount; iIndiceFila++)
            {
                Console.WriteLine(sboResultado.Fields.Item("ItemCode").Value);
                Console.WriteLine(sboResultado.Fields.Item("OnHand").Value);
                Console.WriteLine(sboResultado.Fields.Item("ItmsGrpCod").Value);
                Console.WriteLine(sboResultado.Fields.Item("AvgPrice").Value);
                codigo = sboResultado.Fields.Item("ItemCode").Value;
                stock = sboResultado.Fields.Item("OnHand").Value;
                grupoart = sboResultado.Fields.Item("ItmsGrpCod").Value;
                costo = sboResultado.Fields.Item("AvgPrice").Value;
                icodigoerror = oSociedad.creaDoc(codigo, stock, grupoart, costo);
                //icodigoerror = oSociedad.actualiza(codigo, stock); 
                Console.WriteLine(icodigoerror);
                sboResultado.MoveNext();
            }
            
            //icodigoerror = oSociedad.creaDoc();
           // Console.WriteLine(icodigoerror);

        }
        
    }
}
