﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ConectorSap;
using SAPbobsCOM;

namespace RotacionCosto
{
    internal class Program
    {
        private Mail oMail;
        double inicialSAE;
        double costoVentasSAE;
        double costoVentasSAP;
        double finalSAP;
        double costoProdSAP;
        double vtasTot;
        double promedio;
        double veces;
        double rotacion;
        static void Main(string[] args)
        {
            Program pr = new Program();
            pr.conectar();
            pr.Rotacion();
            pr.desconecta();
        }
        public void conectar()
        {
            int iCodigoError;
            try
            {
                oMail = new Mail();

                iCodigoError = oMail.ConectarDI(ConfigurationManager.AppSettings["TipoServidor"],
                    ConfigurationManager.AppSettings["Servidor"],
                    ConfigurationManager.AppSettings["ServidorSLD"],
                    ConfigurationManager.AppSettings["ServidorLicencia"],
                    ConfigurationManager.AppSettings["BaseDatos"],
                    ConfigurationManager.AppSettings["UsuarioSAP"],
                    ConfigurationManager.AppSettings["PasswordSAP"],
                    ConfigurationManager.AppSettings["UsuarioBD"],
                    ConfigurationManager.AppSettings["PasswordBD"]);

                if (iCodigoError != 0)
                {
                    Console.WriteLine($"Ocurrio un error de conexion {oMail.RecuperrarErrorSBO()}");
                    return;
                }
                else
                {
                    Console.WriteLine($"Conexion Exitosa a Productivo ");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{Environment.NewLine} Error de conexion {ex.Message}");
                Thread.Sleep(50000);
                return;
            }
        }
        public void desconecta()
        {
            try
            {
                oMail.DesconectarDI();
                Console.WriteLine($"{Environment.NewLine} Desconexion exitosa");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{Environment.NewLine} Error al desconectar {ex.Message}");

            }
        }
        public void Rotacion() 
        {
            string sConsultaVtasSap;
            string sConsultaStockFinalSAP;
            string sConsultaProdSap;
            inicialSAE = 60877572.27;
            costoVentasSAE =  102586594.58
;
            costoVentasSAP = 0;
            finalSAP = 0;
            costoProdSAP = 0;
            sConsultaStockFinalSAP = "SELECT SUM(T1.AvgPrice*T1.OnHand) AS 'TOTAL' FROM OITM T0 LEFT OUTER JOIN OITW T1 ON T0.ItemCode=T1.ItemCode " +
                "WHERE T1.WhsCode!='100' AND T1.WhsCode!='110' AND T0.ItmsGrpCod!='101' AND T0.ItmsGrpCod!='106'";
            sConsultaVtasSap = "SELECT T0.[DocNum] AS FACTURA, T1.ItemCode, T1.DocDate,(IIF(T1.ItemCode = 'JAT50910M', (CONVERT(decimal,"+
                 "(SELECT TOP 1 T3.AvgPrice "+
                 "FROM    OITW T3 "+
                 "WHERE T3.ItemCode = SUBSTRING(T1.ItemCode, 1, 8))) / 910) *T1.Quantity, /*-*/ IIF(T1.ItemCode = '5132550M', (CONVERT(decimal, "+
                 "(SELECT TOP 1 T3.AvgPrice "+
                 "FROM    OITW T3 "+
                 "WHERE T3.ItemCode = SUBSTRING(T1.ItemCode, 1, 7))) / 50) * T1.Quantity, /*-*/ IIF(T1.ItemCode = 'JAT75910M', (CONVERT(decimal, "+
                 "(SELECT TOP 1 T3.AvgPrice "+
                 "FROM    OITW T3 "+
                 "WHERE T3.ItemCode = SUBSTRING(T1.ItemCode, 1, 8))) / 910) * T1.Quantity, /*-*/ IIF(T1.ItemCode = 'PETSAM963M', (CONVERT(decimal, "+
                 "(SELECT TOP 1 T3.AvgPrice "+
                 "FROM    OITW T3 "+
                 "WHERE T3.ItemCode = SUBSTRING(T1.ItemCode, 1, 9))) / 150) * T1.Quantity, /*-*/ IIF(T1.ItemCode = '355S496150M', (CONVERT(decimal, "+
                 "(SELECT TOP 1 T3.AvgPrice "+
                 "FROM    OITW T3 "+
                 "WHERE T3.ItemCode = SUBSTRING(T1.ItemCode, 1, 10))) / 150) * T1.Quantity, /*-*/ IIF(T1.ItemCode = '1401-60600M', (CONVERT(decimal, "+
                 "(SELECT TOP 1 T3.AvgPrice "+
                 "FROM    OITW T3 "+
                 "WHERE T3.ItemCode = SUBSTRING(T1.ItemCode, 1, 10))) / 600) * T1.Quantity, /*-*/ IIF(T1.ItemCode = '1401-150600M', (CONVERT(decimal, "+
                 "(SELECT TOP 1 T3.AvgPrice "+
                 "FROM    OITW T3 "+
                 "WHERE T3.ItemCode = SUBSTRING(T1.ItemCode, 1, 11))) / 600) * T1.Quantity, /*-*/ IIF(T1.ItemCode = 'G488/12.560NEGM', (CONVERT(decimal, "+
                 "(SELECT TOP 1 T3.AvgPrice "+
                 "FROM    OITW T3 "+
                 "WHERE T3.ItemCode = SUBSTRING(T1.ItemCode, 1, 14))) / 60) * T1.Quantity, /*-*/ IIF(T1.ItemCode = '510G4850', (CONVERT(decimal, "+
                 "(SELECT TOP 1 T3.AvgPrice "+
                 "FROM    OITW T3 "+
                 "WHERE T3.ItemCode = SUBSTRING(T1.ItemCode, 1, 8)))) * T1.Quantity, /*-*/ IIF(T1.ItemCode = '5611633', (CONVERT(decimal, "+
                 "(SELECT TOP 1 T3.AvgPrice "+
                 "FROM    OITW T3 "+
                 "WHERE T3.ItemCode = SUBSTRING(T1.ItemCode, 1, 7)))) * T1.Quantity, T1.StockValue))))))))))) AS SUBTOTALCOSTO /*END*/ "+
                 "FROM OINV T0 INNER JOIN "+
             "INV1 T1 ON T0.DocEntry = T1.DocEntry LEFT JOIN "+
             "OHEM T3 ON T0.SlpCode = T3.salesPrson INNER JOIN "+
             "ORTT T4 ON T0.DocDate = T4.RateDate INNER JOIN "+
             "OITW T5 ON T1.ItemCode = T5.ItemCode INNER JOIN "+
             "OCRD T6 ON T0.CardCode = T6.CardCode INNER JOIN "+
             "OCTG T7 ON T6.GroupNum = T7.GroupNum "+
             "WHERE T0.DocDate > '2023-07-01' AND T0.CANCELED = 'N' AND T5.WhsCode = '01' AND T0.DocNum > '500000000' AND T4.Currency = 'USD' ";
            /*sConsultaProdSap = "DECLARE @VAR INT, @INI DATETIME, @FIN DATETIME, @ALM NVARCHAR(8) " +
                "SET @INI='2023-08-10' " +
                "SET @FIN=(SELECT CONVERT (date, GETDATE())) " +
                "SELECT ISNULL((SELECT Y.AvgPrice FROM OITW Y WHERE Y.ItemCode=T0.ItemCode AND Y.WhsCode='01'),0)*ISNULL((SELECT (SUM(Y.OutQty)) " +
                "FROM OINM Y WHERE Y.ItemCode = T0.ItemCode AND (Y.DocDate>@INI AND Y.DocDate<@FIN) AND (Y.Warehouse='04' OR Y.Warehouse='01') AND Y.TransType=60),0) AS 'COSTOPROD' " +
                "FROM OITM T0 INNER JOIN OITB T1 ON T0.[ItmsGrpCod]=T1.[ItmsGrpCod] INNER JOIN OITW T3 ON T0.ItemCode=T3.ItemCode WHERE (ISNULL((SELECT (SUM(Y.InQty)-SUM(Y.OutQty)) " +
                "FROM OINM Y WHERE Y.ItemCode = T0.ItemCode AND Y.DocDate <= @FIN AND Y.Warehouse!='100' AND Y.Warehouse!='110'),0))>=0 AND T3.AvgPrice!=0 AND T3.WhsCode=1 ORDER BY T0.[ItemCode]";*/
            SAPbobsCOM.Recordset sboResultadoStockFinal;
            SAPbobsCOM.Recordset sboResultadoVtasSap;
            string sError;
            sboResultadoStockFinal = oMail.GeneraConsulta(sConsultaStockFinalSAP, out sError);
            if (sError != string.Empty)
            {
                Console.WriteLine($"{Environment.NewLine} Error al Buscar {sError}");
                return;
            }
            finalSAP = sboResultadoStockFinal.Fields.Item("TOTAL").Value;
            Console.WriteLine($"{Environment.NewLine} {finalSAP}");
            sboResultadoVtasSap=oMail.GeneraConsulta(sConsultaVtasSap, out sError);
            if (sError != string.Empty)
            {
                Console.WriteLine($"{Environment.NewLine} Error al Buscar {sError}");
                return;
            }
            for (int i = 0; i < sboResultadoVtasSap.RecordCount; i++)
            {
                costoVentasSAP = costoVentasSAP+sboResultadoVtasSap.Fields.Item("SUBTOTALCOSTO").Value;
                sboResultadoVtasSap.MoveNext();
            }

            vtasTot = costoVentasSAE + costoVentasSAP;
            promedio = (inicialSAE + finalSAP) / 2;
           
            veces = vtasTot / promedio;
            
            DateTime inicio = new DateTime(2023, 01, 02);
            DateTime fin = DateTime.Now;
            int fecha=(fin-inicio).Days+1;
           
            rotacion = fecha / veces;
            string stockInicial = String.Format("{0:C}", inicialSAE);
            string stockFinal = String.Format("{0:C}", finalSAP);
            string invPromedio = String.Format("{0:C}", promedio);
            string days = String.Format("{0:0.00}", veces);
            string subject = $"Rotacion de Inventario al {fin.ToShortDateString()}";
            string body = $"Inventario Inicial: {stockInicial}</br>Inventario Final: {stockFinal}</br>Inventario Promedio: {invPromedio}</br>" +
                $"Veces en el periodo: {days}</br>Dias del periodo a partir del {inicio.ToShortDateString()}: {Convert.ToInt32(fecha)} dias</br>La rotacion del inventario al dia: {fin.ToShortDateString()} es {Convert.ToInt32(rotacion)} dias</br></br>" +
                $"SISTEMA ELECTRÓNICO DE INFORMACIÓN COVE</br></br>Cintas Cove, S.A. de C.V.</br>EMPRESA ISO9001:2015 certificada</br>visit us at: www.cintascove.com</br>" +
                $"SISTEMA AUTOMATIZADO.  FAVOR DE NO RESPONDER.</br></br>Send by SAP BO ";
            Console.WriteLine($"{Environment.NewLine}inicial SAE{inicialSAE}");
            Console.WriteLine($"{Environment.NewLine}final SAP {finalSAP}");
            Console.WriteLine($"{Environment.NewLine}vtas SAP{costoVentasSAP}");
            Console.WriteLine($"{Environment.NewLine}vtas SAE{costoVentasSAE}");
            Console.WriteLine($"{Environment.NewLine}Promedio{invPromedio}");
            Console.WriteLine($"{Environment.NewLine}ventas{vtasTot}");
            Console.WriteLine($"{Environment.NewLine}fecha{fecha}");
            Console.WriteLine($"{Environment.NewLine}veces{veces}");
            Console.WriteLine($"{Environment.NewLine}rotacion{rotacion}");
            oMail.sendMail(subject, body, "mcuevas@cintascove.com");
        }
    }
}
