﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using SAPbobsCOM;
namespace ConectorSap
{
    public class Conector
    {
        Company sboConexionPruebas=new Company();
        Company sboConexionDI=new Company();

        public int ConectarPruebas(string sTipoServidor, string sServidor, string sServidorSLD, string sServidorLicencias, string sBaseDatos, string sUsuarioSAP, string sPasswordSAP, string sUsuarioBD, string sPasswordBD) 
        {
            int iCodigoError;
            try
            {
                sBaseDatos = "COVE_PRUEBA3";
                sPasswordSAP = "Cov3ec0#1";
                //agregando datos de conexion.
                sboConexionPruebas.DbServerType = (BoDataServerTypes)Enum.Parse(typeof(BoDataServerTypes), sTipoServidor);   //dst_MSSQL2017
                sboConexionPruebas.Server = sServidor;
                sboConexionPruebas.SLDServer = sServidorSLD;
                sboConexionPruebas.LicenseServer = sServidorLicencias;
                sboConexionPruebas.CompanyDB = sBaseDatos;
                sboConexionPruebas.UserName = sUsuarioSAP;
                sboConexionPruebas.Password = sPasswordSAP;
                sboConexionPruebas.DbUserName = sUsuarioBD;
                sboConexionPruebas.DbPassword = sPasswordBD;

                iCodigoError = sboConexionPruebas.Connect();
                return iCodigoError;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al conectar {ex.Message}");
            }
        }
        public int ConectarDI(string sTipoServidor, string sServidor, string sServidorSLD, string sServidorLicencias, string sBaseDatos, string sUsuarioSAP, string sPasswordSAP, string sUsuarioBD, string sPasswordBD)
        {
            int iCodigoError;
            try
            {
                //agregando datos de conexion.
                sboConexionDI.DbServerType = (BoDataServerTypes)Enum.Parse(typeof(BoDataServerTypes), sTipoServidor);   //dst_MSSQL2017
                sboConexionDI.Server = sServidor;
                sboConexionDI.SLDServer = sServidorSLD;
                sboConexionDI.LicenseServer = sServidorLicencias;
                sboConexionDI.CompanyDB = sBaseDatos;
                sboConexionDI.UserName = sUsuarioSAP;
                sboConexionDI.Password = sPasswordSAP;
                sboConexionDI.DbUserName = sUsuarioBD;
                sboConexionDI.DbPassword = sPasswordBD;

                iCodigoError = sboConexionDI.Connect();
                return iCodigoError;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al conectar {ex.Message}");
            }
        }
        public string RecuperrarErrorSBO()
        {
            string sError;
            try
            {
                sError = sboConexionDI.GetLastErrorDescription();
                return sError;
            }
            catch (Exception e)
            {
                return $"error al recuperar el erroe SBO {e.Message}";
            }
        }
        public string RecuperrarErrorSBOPruebas()
        {
            string sError;
            try
            {
                sError = sboConexionPruebas.GetLastErrorDescription();
                return sError;
            }
            catch (Exception e)
            {
                return $"error al recuperar el erroer pr SBO {e.Message}";
            }
        }
        public void DesconectarDI()
        {
            try
            {
                if (sboConexionDI.Connected)
                    sboConexionDI.Disconnect();
                if(sboConexionPruebas.Connected)
                    sboConexionPruebas.Disconnect();
            }
            catch (Exception e)
            {
                throw new Exception($"Ocurrio un error al desconectar: {e.Message}");
            }
        }
        public Recordset GeneraConsulta(string sConsulta, out string sError)
        {//Recupera la consulta de el respaldo 
            Recordset sboConsulta;
            try
            {
                sError = string.Empty;
                //sboConsulta = sboConexionPruebas.GetBusinessObject(BoObjectTypes.BoRecordset); PRUEBAS
                sboConsulta = sboConexionDI.GetBusinessObject(BoObjectTypes.BoRecordset);

                sboConsulta.DoQuery(sConsulta);

                if (sboConsulta.RecordCount == 0)
                {
                    throw new Exception($"No se encontraron registros");
                }

                return sboConsulta;
            }
            catch (Exception ex)
            {
                sError = ex.Message;
                return null;
            }
        }
        public int creaDoc(string codigo,double stock,int grupoart,double costo) 
        {
                string fecha = "2023-10-11";
                //string fecha = DateTime.Now.ToString("yyyy-MM-dd");

                int iCodigoError=-2;
                string code = codigo + ","+fecha;
                //sboConexionDI.GetBusinessObject(BoObjectTypes.oUserTables);
                UserTable oUserTable;
                //oUserTable=sboConexionDI.UserTables.Item(42);
                oUserTable = sboConexionDI.UserTables.Item(41);
                oUserTable.Code = code;
                oUserTable.Name = code;
                oUserTable.UserFields.Fields.Item("U_art").Value = codigo;
                oUserTable.UserFields.Fields.Item("U_stock").Value = stock;
                oUserTable.UserFields.Fields.Item("U_grupoart").Value = grupoart;
                oUserTable.UserFields.Fields.Item("U_costo").Value = costo;
                oUserTable.UserFields.Fields.Item("U_fecha").Value = fecha;
                iCodigoError = oUserTable.Add();
                return iCodigoError;
            
        }
        public int actualiza(string codigo, double stock) 
        { 
            int iCodigoError;
            string fecha = "2023-10-04";
            string code = codigo + ","+fecha;
            //sboConexionDI.GetBusinessObject(BoObjectTypes.oUserTables);
            UserTable oUserTable;
            oUserTable = sboConexionDI.UserTables.Item(42);
            if (!oUserTable.GetByKey(code)) 
            {
                iCodigoError = -1;
            }
            oUserTable.UserFields.Fields.Item("U_stock").Value = stock;
            oUserTable.UserFields.Fields.Item("U_fecha").Value = fecha;//cambiar la fecha del dia 25
            iCodigoError = oUserTable.Update();
            return iCodigoError;
        }

        public int altaEmail(string sNombre,string sApellido,string sEmail,string sSexo,string iCambio) 
        {
            int iCodigoError;
            string fecha = DateTime.Now.ToString("yyyy-MM-dd");
            string code = fecha + sNombre;
            UserTable oUserTable;
            oUserTable=sboConexionDI.UserTables.Item(41);
            oUserTable.Code = code;
            oUserTable.Name = code;
            oUserTable.UserFields.Fields.Item("U_Nom").Value = sNombre;
            oUserTable.UserFields.Fields.Item("U_Ap").Value = sApellido;
            oUserTable.UserFields.Fields.Item("U_Email").Value = sEmail;
            oUserTable.UserFields.Fields.Item("U_Sexo").Value = sSexo;
            oUserTable.UserFields.Fields.Item("U_Tcambio").Value = iCambio;
            iCodigoError = oUserTable.Add();

            return iCodigoError;
        }
    }
}
