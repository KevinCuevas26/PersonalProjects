﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SAPbobsCOM;
using System.Net;
using System.Net.Mail;
using System.Security.Policy;
using System.Xml.Linq;

namespace ConectorSap
{
    public class Mail
    {
        Company sboConexionDI = new Company();
        public int ConectarDI(string sTipoServidor, string sServidor, string sServidorSLD, string sServidorLicencias, string sBaseDatos, string sUsuarioSAP, string sPasswordSAP, string sUsuarioBD, string sPasswordBD)
        {
            int iCodigoError;
            try
            {
                //agregando datos de conexion.
                sboConexionDI.DbServerType = (BoDataServerTypes)Enum.Parse(typeof(BoDataServerTypes), sTipoServidor);   //dst_MSSQL2017
                sboConexionDI.Server = sServidor;
                sboConexionDI.SLDServer = sServidorSLD;
                sboConexionDI.LicenseServer = sServidorLicencias;
                sboConexionDI.CompanyDB = sBaseDatos;
                sboConexionDI.UserName = sUsuarioSAP;
                sboConexionDI.Password = sPasswordSAP;
                sboConexionDI.DbUserName = sUsuarioBD;
                sboConexionDI.DbPassword = sPasswordBD;

                iCodigoError = sboConexionDI.Connect();
                return iCodigoError;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al conectar {ex.Message}");
            }
        }
        public string RecuperrarErrorSBO()
        {
            string sError;
            try
            {
                sError = sboConexionDI.GetLastErrorDescription();
                return sError;
            }
            catch (Exception e)
            {
                return $"error al recuperar el erroe SBO {e.Message}";
            }
        }
        public void DesconectarDI()
        {
            try
            {
                if (sboConexionDI.Connected)
                    sboConexionDI.Disconnect();
            }
            catch (Exception e)
            {
                throw new Exception($"Ocurrio un error al desconectar: {e.Message}");
            }
        }
        public void send(string sContacto, string sdire, double dTipoCambio, string sSexo)
        {
            string fecha = DateTime.Now.ToString("yyyy/MM/dd");
            var fromAddress = new MailAddress("coveinfo@cintascove.com", "From Name");
            var toAddress = new MailAddress(sdire, "To Name");
            const string fromPassword = "Ecocove16";
            string subject = "TIPO DE CAMBIO AL " + fecha;
            string sEst = "";
            if (sSexo == "M")
            {
                sEst = "Estimado ";
            }
            else
            {
                sEst = "Estimada ";
            }
            string body = $"{sEst} {sContacto}: \r\nEl tipo de cambio al día {fecha} es: ${dTipoCambio}\r\n \r\n SISTEMA ELECTRONICO DE INFORMACION COVE\r\n\r\nCintas Cove, S.A. de C.V.\r\nvisit us at: www.cintascove.com\r\nSISTEMA AUTOMATIZADO.  FAVOR DE NO RESPONDER.\r\n\r\nSend by SAP BO ";

            var smtp = new SmtpClient
            {
                Host = "smtp.office365.com",
                Port = 587,
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(fromAddress.Address, fromPassword)
            };
            using (var message = new MailMessage(fromAddress, toAddress)
            {
                Subject = subject,
                Body = body
            })
            {
                smtp.Send(message);
            }
        }
        public Recordset GeneraConsulta(string sConsulta, out string sError)
        {
            Recordset sboConsulta;
            try
            {
                sError = string.Empty;
                sboConsulta = sboConexionDI.GetBusinessObject(BoObjectTypes.BoRecordset);

                sboConsulta.DoQuery(sConsulta);

                if (sboConsulta.RecordCount == 0)
                {
                    throw new Exception($"No se encontraron registros");
                }

                return sboConsulta;
            }
            catch (Exception ex)
            {
                sError = ex.Message;
                return null;
            }

        }
        public void enviaCorreo(string subject, string body, string sdire)
        {
            var toAddress = new MailAddress(sdire, "To Name");
            string toCAddress = "mcuevas@cintascove.com";
            using (MailMessage message = new MailMessage())
            {
                message.From = new MailAddress("coveinfo@cintascove.com");
                message.To.Add("ecoronab@cintascove.com");
                message.To.Add("joseluisdiaz@cintascove.com");
                message.To.Add("gcorona@cintascove.com");
                message.CC.Add("flopez@cintascove.com");
                message.CC.Add("sgarcia@cintascove.com");
                message.CC.Add("jasantiago@cintascove.com");
                message.Bcc.Add(toCAddress);
                message.Subject = subject;
                message.Body = body;
                message.IsBodyHtml = true;
                using (SmtpClient smtp = new SmtpClient("smtp.office365.com", 587))
                {
                    smtp.Credentials = new NetworkCredential("coveinfo@cintascove.com", "Ecocove16");
                    smtp.EnableSsl = true;
                    smtp.Send(message);
                }

            }
        }
        public void sendMail(string subject, string body, string sdire) 
        {
            string[] correos = {"ecoronab@cintascove.com","joseluisdiaz@cintascove.com","gcorona@cintascove.com", "sgarcia@cintascove.com", "jasantiago@cintascove.com","mcuevas@cintascove.com","compras@cintascove.com","gracielacorona@cintascove.com" };
            string[] nombres = {"Eduardo Corona", "Jose Luis Diaz","Gabriela Corona", "Sergio Garcia", "Jose Armando Santiago", "Kevin Cuevas", "Ayamain Ameyalli Matamoros","Graciela Corona" };
            string[] sexo = { "M", "M", "F", "M", "M", "M", "F", "F" };
            string cuerpo;
            for (int i = 0; i < correos.Length; i++)
            {
                if (sexo[i] == "M")
                {
                    cuerpo = $"Estimado {nombres[i]}</br></br>";
                }
                else
                {
                    cuerpo = $"Estimada {nombres[i]}</br></br>";
                }
                cuerpo += body;
                using (MailMessage message = new MailMessage())
                {
                    message.From = new MailAddress("coveinfo@cintascove.com");
                    message.To.Add(correos[i]);
                    message.Subject = subject;
                    message.Body = cuerpo;
                    message.IsBodyHtml = true;
                    using (SmtpClient smtp = new SmtpClient("smtp.office365.com", 587))
                    {
                        smtp.Credentials = new NetworkCredential("coveinfo@cintascove.com", "Ecocove16");
                        smtp.EnableSsl = true;
                        smtp.Send(message);
                    }

                }
            }
        }
    }
}
