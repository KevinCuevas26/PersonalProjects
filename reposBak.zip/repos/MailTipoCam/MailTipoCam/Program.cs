﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConectorSap;
using SAPbobsCOM;
namespace MailTipoCam
{
    internal class Program
    {
        private Mail oMail;

        static void Main(string[] args)
        {
            Program pr = new Program();
            pr.conectar();
            pr.recuperaCambio();
            pr.desconecta();

        }
        public void conectar()
        {
            int iCodigoError;
            try
            {
                oMail = new Mail();

                iCodigoError = oMail.ConectarDI(ConfigurationManager.AppSettings["TipoServidor"],
                    ConfigurationManager.AppSettings["Servidor"],
                    ConfigurationManager.AppSettings["ServidorSLD"],
                    ConfigurationManager.AppSettings["ServidorLicencia"],
                    ConfigurationManager.AppSettings["BaseDatos"],
                    ConfigurationManager.AppSettings["UsuarioSAP"],
                    ConfigurationManager.AppSettings["PasswordSAP"],
                    ConfigurationManager.AppSettings["UsuarioBD"],
                    ConfigurationManager.AppSettings["PasswordBD"]);

                if (iCodigoError != 0)
                {
                    Console.WriteLine($"Ocurrio un error de conexion {oMail.RecuperrarErrorSBO()}");
                    return;
                }
                else
                {
                    Console.WriteLine($"Conexion Exitosa a Productivo ");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{Environment.NewLine} Error de conexion {ex.Message}");
                return;
            }
        }
        public void desconecta()
        {
            try
            {
                oMail.DesconectarDI();
                Console.WriteLine($"{Environment.NewLine} Desconexion exitosa");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{Environment.NewLine} Error al desconectar {ex.Message}");

            }
        }
        public void recuperaCambio ()
        {
            string sConsultaCambio;
            string sConsultaEmail;
            double dTipoCambio;
            sConsultaCambio = "DECLARE @INI DATETIME SET @INI=(SELECT CONVERT (date, GETDATE())) SELECT T0.Rate  FROM ORTT T0 WHERE T0.RateDate=@INI";
            SAPbobsCOM.Recordset sboResultado;
            string sError;
            sboResultado = oMail.GeneraConsulta(sConsultaCambio, out sError);
            if (sError != string.Empty)
            {
                Console.WriteLine($"{Environment.NewLine} Error al Buscar {sError}");
                return;
            }

            dTipoCambio=sboResultado.Fields.Item("Rate").Value;

            sConsultaEmail = "SELECT T0.U_Nom, T0.U_Ap, T0.U_Email, T0.U_Sexo FROM [dbo].[@UCOVE_EMAIL]  T0 WHERE T0.U_Tcambio='1'";
            sboResultado = oMail.GeneraConsulta(sConsultaEmail, out sError);
            if (sError != string.Empty)
            {
                Console.WriteLine($"{Environment.NewLine} Error al Buscar {sError}");
                return;
            }
            string sContacto;string sEmail;string sSexo;
            for (int j=0;j < sboResultado.RecordCount;j++) 
            {
                sContacto = sboResultado.Fields.Item("U_Nom").Value+" "+ sboResultado.Fields.Item("U_Ap").Value;
                sSexo = sboResultado.Fields.Item("U_Sexo").Value;
                sEmail = sboResultado.Fields.Item("U_Email").Value;
                envioMail(sContacto, sEmail, dTipoCambio,sSexo);
                sboResultado.MoveNext();
            }
        }
        public void envioMail(string sContacto, string sMails,double dTipoCambio,string sSexo) 
        {
            /*string[] mails = { "mcuevas@cintascove.com", "fgomez@cintascove.com" };
            for (int i = 0; i < mails.Length; i++)
            {*/
                oMail.send(sContacto,sMails,dTipoCambio,sSexo);
            //}
        }
    }
}
