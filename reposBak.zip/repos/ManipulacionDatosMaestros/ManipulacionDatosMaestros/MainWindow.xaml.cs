﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using ConectorDIAPI;

namespace ManipulacionDatosMaestros
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Conector oSociedad= new Conector();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnConectar_Click(object sender, RoutedEventArgs e)
        {
            int iCodigoError;
            try
            {
                iCodigoError = oSociedad.ConectarDI(ConfigurationManager.AppSettings["TipoServidor"],
                    ConfigurationManager.AppSettings["Servidor"],
                    ConfigurationManager.AppSettings["ServidorSLD"],
                    ConfigurationManager.AppSettings["ServidorLicencia"],
                    ConfigurationManager.AppSettings["BaseDatos"],
                    ConfigurationManager.AppSettings["UsuarioSAP"],
                    ConfigurationManager.AppSettings["PasswordSAP"],
                    ConfigurationManager.AppSettings["UsuarioBD"],
                    ConfigurationManager.AppSettings["PasswordBD"]);

                if (iCodigoError != 0)
                {
                    tbMensajes.AppendText($"Ocurrio un error de conexion {oSociedad.RecuperrarErrorSBO()}");
                }
                else
                {
                    tbMensajes.AppendText($"Conexion Exitosa ");
                }
            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error de conexion {ex.Message}");
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btnDesconectar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                oSociedad.DesconectarDI();
                tbMensajes.AppendText($"{Environment.NewLine} Desconexion exitosa");
            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error al desconectar {ex.Message}");

            }
        }

        private void btnBuscar_Copiar_Click(object sender, RoutedEventArgs e)
        {
            string sCodigoDatoMaestro;
            string sDescripcion;
            try 
            {
                
                if (!oSociedad.ValidaDIConectado())
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Conecte a la BD");
                    return;
                }
                if (cbTipoObjeto.SelectedItem == null) {
                    tbMensajes.AppendText($"{Environment.NewLine} Seleccione tipo de dato a buscar");
                    return;
                }
                if (tbCodigo.Text==string.Empty)
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Ingrese Codigo");
                    return;
                }
                sCodigoDatoMaestro = tbCodigo.Text;

                tbMensajes.AppendText($"{Environment.NewLine}Buscando dato maestro...");
                
                ListBoxItem oSeleccionado = (ListBoxItem)cbTipoObjeto.SelectedItem;
                sDescripcion = oSociedad.RecuperaDatoMaestro(oSeleccionado.Content.ToString(), sCodigoDatoMaestro);
                

                if (sDescripcion.Contains("Error"))
                { 
                    tbMensajes.AppendText($"{Environment.NewLine}");
                    return;
                }

                tbDescripcion.Text = sDescripcion;
                tbMensajes.AppendText($"{Environment.NewLine}Dato maestro Recuperado");

            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error en la busqueda  {ex.Message}");
                tbMensajes.AppendText($"{Environment.NewLine} Conecte a la BD");
                    return;
            }
        }

        private void btnActualizar_Click(object sender, RoutedEventArgs e)
        {
            string sCodigoDatoMaestro;
            int iCodigoRespuesta;
            try {
                if (!oSociedad.ValidaDIConectado())
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Conecte a la BD");
                    return;
                }
                if (cbTipoObjeto.SelectedItem == null)
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Seleccione tipo de dato a buscar");
                    return;
                }
                if (tbCodigo.Text == string.Empty)
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Ingrese Codigo");
                    return;
                }
                sCodigoDatoMaestro = tbCodigo.Text;

                tbMensajes.AppendText($"{Environment.NewLine}Actualizando dato maestro...");


                ListBoxItem oSeleccionado = (ListBoxItem)cbTipoObjeto.SelectedItem;
                iCodigoRespuesta = oSociedad.ActualizarDatoMaestro(oSeleccionado.Content.ToString(), sCodigoDatoMaestro,tbDescripcion.Text);

                if (iCodigoRespuesta != 0) { 
                    tbMensajes.AppendText($"{Environment.NewLine}Hubo un error al actualizar {tbCodigo}: {oSociedad.RecuperrarErrorSBO()}");
                    return;
                }
                tbMensajes.AppendText($"{Environment.NewLine}Actualizado con exito");
            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error en la actualizacion  {ex.Message}");
                tbMensajes.AppendText($"{Environment.NewLine} Conecte a la BD");
                return;
            }
        }
    }
}
