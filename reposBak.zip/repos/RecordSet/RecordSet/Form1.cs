﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConectorDIAPI;
using SAPbobsCOM;

using System.Configuration;

namespace RecordSet
{
    public partial class Form1 : Form
    {
        private Conector oSociedad;
        public Form1()
        {
            InitializeComponent();
            conectar();
        }
        private void conectar()
        {
            int iCodigoError;
            try
            {
                oSociedad = new Conector();

                iCodigoError = oSociedad.ConectarDI(ConfigurationManager.AppSettings["TipoServidor"],
                    ConfigurationManager.AppSettings["Servidor"],
                    ConfigurationManager.AppSettings["ServidorSLD"],
                    ConfigurationManager.AppSettings["ServidorLicencia"],
                    ConfigurationManager.AppSettings["BaseDatos"],
                    ConfigurationManager.AppSettings["UsuarioSAP"],
                    ConfigurationManager.AppSettings["PasswordSAP"],
                    ConfigurationManager.AppSettings["UsuarioBD"],
                    ConfigurationManager.AppSettings["PasswordBD"]);

                if (iCodigoError != 0)
                {
                    tbMensajes.AppendText($"Ocurrio un error de conexion {oSociedad.RecuperrarErrorSBO()}");
                }
                else
                {
                    tbMensajes.AppendText($"Conexion Exitosa ");
                }
            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error de conexion {ex.Message}");
            }
        }
        private void btnDesconectar_Click(object sender, EventArgs e)
        {
            try
            {
                oSociedad.DesconectarDI();
                tbMensajes.AppendText($"{Environment.NewLine} Desconexion exitosa");
            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error al desconectar {ex.Message}");

            }
        }

        private void btnRecuperar_Click(object sender, EventArgs e)
        {
            int iIndice=0;
            string sConsulta;
            string sError;
            List<Dictionary<string, object>> lResultados;
            try
            {
                if (!oSociedad.ValidaDIConectado())
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Conecte a la BD");
                    return;
                }
                if (cbSocios.SelectedItem == null)
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Seleccione el tipo de socio de negocios a buscar");
                    return;
                }

                sConsulta = "SELECT CardCode, CardName, CardType, LicTradNum, SlpCode, firstName FROM OCRD LEFT JOIN OHEM ON (SlpCode = salesPrson) @CONDITION";
                switch(cbSocios.SelectedItem.ToString())
                {
                    case "Todos":
                            sConsulta = sConsulta.Replace("@CONDITION", "");
                        break;
                    case "Clientes":
                            sConsulta = sConsulta.Replace("@CONDITION", "WHERE CardType='C' ");
                        break;
                    case "Proveedores":
                            sConsulta = sConsulta.Replace("@CONDITION", "WHERE CardType='S' ");
                        break;
                    default:
                        tbMensajes.AppendText($"{Environment.NewLine} Filtro no valido babas");
                        return;
                }
                lResultados=oSociedad.GeneraConsulta(sConsulta,out sError);
                if (sError != string.Empty)
                {
                    tbMensajes.AppendText($"{Environment.NewLine}Error al Buscar al socio de negocios");
                }
                if (lResultados.Count == 0) 
                { 
                    tbMensajes.AppendText($"{Environment.NewLine}No se encontraron socios de negocios");

                }
                dgSocios.Rows.Clear();
                dgSocios.Rows.Add(lResultados.Count - 1);

                foreach(Dictionary<string,object> dFila in lResultados)
                {
                    dgSocios.Rows[iIndice].Cells["CardCode"].Value = dFila["CardCode"].ToString();
                    dgSocios.Rows[iIndice].Cells["CardName"].Value = dFila["CardName"].ToString();
                    dgSocios.Rows[iIndice].Cells["CardType"].Value = dFila["CardType"].ToString();
                    dgSocios.Rows[iIndice].Cells["LiCTradNum"].Value = dFila["LicTradNum"].ToString();
                    dgSocios.Rows[iIndice].Cells["SlpCode"].Value = dFila["SlpCode"].ToString();
                    dgSocios.Rows[iIndice].Cells["firstName"].Value = dFila["firstName"].ToString();
                    iIndice++;
                }

                /*

                SAPbobsCOM.Recordset sboResultado;
                string sError;
                sboResultado = oSociedad.GeneraConsulta(sConsulta, out sError);
                if(sError != string.Empty) 
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Error al Buscar al socio de negocios");
                }
                sboResultado.MoveFirst();
                dgSocios.Rows.Clear();  
                dgSocios.Rows.Add(sboResultado.RecordCount -1);

                for(int iIndiceFila = 0;iIndiceFila<sboResultado.RecordCount;iIndiceFila++) 
                {
                    dgSocios.Rows[iIndiceFila].Cells["CardCode"].Value = sboResultado.Fields.Item("CardCode").Value;
                    dgSocios.Rows[iIndiceFila].Cells["CardName"].Value = sboResultado.Fields.Item("CardName").Value;
                    dgSocios.Rows[iIndiceFila].Cells["CardType"].Value = sboResultado.Fields.Item("CardType").Value;
                    dgSocios.Rows[iIndiceFila].Cells["LiCTradNum"].Value = sboResultado.Fields.Item("LicTradNum").Value;
                    dgSocios.Rows[iIndiceFila].Cells["SlpCode"].Value = sboResultado.Fields.Item("SlpCode").Value;
                    dgSocios.Rows[iIndiceFila].Cells["firstName"].Value = sboResultado.Fields.Item("firstName").Value;
                    sboResultado.MoveNext();
                }
                */



            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error al Buscar el socio de negocio {ex.Message}");

            }
        }
    }
}
