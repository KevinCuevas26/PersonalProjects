﻿namespace RecordSet
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbSocios = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDesconectar = new System.Windows.Forms.Button();
            this.btnRecuperar = new System.Windows.Forms.Button();
            this.dgSocios = new System.Windows.Forms.DataGridView();
            this.tbMensajes = new System.Windows.Forms.TextBox();
            this.CardCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CardName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CardType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LiCTradNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SlpCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgSocios)).BeginInit();
            this.SuspendLayout();
            // 
            // cbSocios
            // 
            this.cbSocios.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSocios.FormattingEnabled = true;
            this.cbSocios.Items.AddRange(new object[] {
            "Todos",
            "Clientes",
            "Proveedores"});
            this.cbSocios.Location = new System.Drawing.Point(116, 22);
            this.cbSocios.Name = "cbSocios";
            this.cbSocios.Size = new System.Drawing.Size(194, 28);
            this.cbSocios.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Socios";
            // 
            // btnDesconectar
            // 
            this.btnDesconectar.Location = new System.Drawing.Point(12, 393);
            this.btnDesconectar.Name = "btnDesconectar";
            this.btnDesconectar.Size = new System.Drawing.Size(162, 52);
            this.btnDesconectar.TabIndex = 2;
            this.btnDesconectar.Text = "Desconectar";
            this.btnDesconectar.UseVisualStyleBackColor = true;
            this.btnDesconectar.Click += new System.EventHandler(this.btnDesconectar_Click);
            // 
            // btnRecuperar
            // 
            this.btnRecuperar.Location = new System.Drawing.Point(201, 393);
            this.btnRecuperar.Name = "btnRecuperar";
            this.btnRecuperar.Size = new System.Drawing.Size(162, 52);
            this.btnRecuperar.TabIndex = 3;
            this.btnRecuperar.Text = "Recuperar";
            this.btnRecuperar.UseVisualStyleBackColor = true;
            this.btnRecuperar.Click += new System.EventHandler(this.btnRecuperar_Click);
            // 
            // dgSocios
            // 
            this.dgSocios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgSocios.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CardCode,
            this.CardName,
            this.CardType,
            this.LiCTradNum,
            this.SlpCode,
            this.firstName});
            this.dgSocios.Location = new System.Drawing.Point(13, 73);
            this.dgSocios.Name = "dgSocios";
            this.dgSocios.RowHeadersWidth = 62;
            this.dgSocios.RowTemplate.Height = 28;
            this.dgSocios.Size = new System.Drawing.Size(1024, 287);
            this.dgSocios.TabIndex = 5;
            // 
            // tbMensajes
            // 
            this.tbMensajes.Location = new System.Drawing.Point(432, 380);
            this.tbMensajes.Multiline = true;
            this.tbMensajes.Name = "tbMensajes";
            this.tbMensajes.Size = new System.Drawing.Size(523, 64);
            this.tbMensajes.TabIndex = 6;
            // 
            // CardCode
            // 
            this.CardCode.HeaderText = "Socio";
            this.CardCode.MinimumWidth = 8;
            this.CardCode.Name = "CardCode";
            this.CardCode.ReadOnly = true;
            this.CardCode.Width = 150;
            // 
            // CardName
            // 
            this.CardName.HeaderText = "Nombre";
            this.CardName.MinimumWidth = 8;
            this.CardName.Name = "CardName";
            this.CardName.ReadOnly = true;
            this.CardName.Width = 150;
            // 
            // CardType
            // 
            this.CardType.HeaderText = "Tipo ";
            this.CardType.MinimumWidth = 8;
            this.CardType.Name = "CardType";
            this.CardType.ReadOnly = true;
            this.CardType.Width = 150;
            // 
            // LiCTradNum
            // 
            this.LiCTradNum.HeaderText = "RFC";
            this.LiCTradNum.MinimumWidth = 8;
            this.LiCTradNum.Name = "LiCTradNum";
            this.LiCTradNum.ReadOnly = true;
            this.LiCTradNum.Width = 150;
            // 
            // SlpCode
            // 
            this.SlpCode.HeaderText = "Empleado Vtas";
            this.SlpCode.MinimumWidth = 8;
            this.SlpCode.Name = "SlpCode";
            this.SlpCode.ReadOnly = true;
            this.SlpCode.Width = 150;
            // 
            // firstName
            // 
            this.firstName.HeaderText = "firstName";
            this.firstName.MinimumWidth = 8;
            this.firstName.Name = "firstName";
            this.firstName.Width = 150;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1056, 472);
            this.Controls.Add(this.tbMensajes);
            this.Controls.Add(this.dgSocios);
            this.Controls.Add(this.btnRecuperar);
            this.Controls.Add(this.btnDesconectar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbSocios);
            this.Name = "Form1";
            this.Text = "Manejo de Recordset";
            ((System.ComponentModel.ISupportInitialize)(this.dgSocios)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbSocios;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDesconectar;
        private System.Windows.Forms.Button btnRecuperar;
        private System.Windows.Forms.DataGridView dgSocios;
        private System.Windows.Forms.TextBox tbMensajes;
        private System.Windows.Forms.DataGridViewTextBoxColumn CardCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn CardName;
        private System.Windows.Forms.DataGridViewTextBoxColumn CardType;
        private System.Windows.Forms.DataGridViewTextBoxColumn LiCTradNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn SlpCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstName;
    }
}

