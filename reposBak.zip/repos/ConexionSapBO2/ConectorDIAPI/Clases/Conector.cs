﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConectorDIAPI.CICO;
using SAPbobsCOM;

namespace ConectorDIAPI
{
    public class Conector
    {
        Company sboConexionDI = new Company();
        public int ConectarDI(string sTipoServidor, string sServidor, string sServidorSLD, string sServidorLicencias, string sBaseDatos, string sUsuarioSAP, string sPasswordSAP, string sUsuarioBD, string sPasswordBD)
        {
            int iCodigoError;
            try
            {
                sBaseDatos = "COVE_PRUEBAS2";
                //agregando datos de conexion.
                sboConexionDI.DbServerType = (BoDataServerTypes)Enum.Parse(typeof(BoDataServerTypes), sTipoServidor);   //dst_MSSQL2017
                sboConexionDI.Server = sServidor;
                sboConexionDI.SLDServer = sServidorSLD;
                sboConexionDI.LicenseServer = sServidorLicencias;
                sboConexionDI.CompanyDB = sBaseDatos;
                sboConexionDI.UserName = sUsuarioSAP;
                sboConexionDI.Password = sPasswordSAP;
                sboConexionDI.DbUserName = sUsuarioBD;
                sboConexionDI.DbPassword = sPasswordBD;

                iCodigoError = sboConexionDI.Connect();
                return iCodigoError;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al conectar {ex.Message}");
            }

        }
        public string RecuperrarErrorSBO()
        {
            string sError;
            try
            {
                sError = sboConexionDI.GetLastErrorDescription();
                return sError;
            }
            catch (Exception e)
            {
                return $"error al recuperar el erroe SBO {e.Message}";
            }
        }
        public void DesconectarDI()
        {
            try
            {
                if (sboConexionDI.Connected)
                    sboConexionDI.Disconnect();
            }
            catch (Exception e)
            {
                throw new Exception($"Ocurrio un error al desconectar: {e.Message}");
            }
        }

        public bool ValidaDIConectado()
        {
            try
            {
                return sboConexionDI.Connected;
            }
            catch (Exception e)
            {
                throw new Exception($"Ocurrio un error : {e.Message}");
            }
        }

        public string RecuperaDatoMaestro(string sTipoObjeto, string scodigo)
        {
            string sDescripcion;
            Items sboDatoMaestroArticulo;// dato maestro del articulo
            BusinessPartners sboDatoMaestroSocioNegocios;//datos maestros del socio de negocios
            try
            {
                switch (sTipoObjeto)
                {
                    case "Articulo":
                        sboDatoMaestroArticulo = sboConexionDI.GetBusinessObject(BoObjectTypes.oItems);
                        //buscar el articulo RG221850
                        if (!sboDatoMaestroArticulo.GetByKey(scodigo))
                        {
                            throw new Exception($"No existe el articulo {scodigo}");
                        }
                        sDescripcion = sboDatoMaestroArticulo.ItemName;
                        break;
                    case "Socio de negocio":
                        sboDatoMaestroSocioNegocios = sboConexionDI.GetBusinessObject(BoObjectTypes.oBusinessPartners);

                        if (!sboDatoMaestroSocioNegocios.GetByKey(scodigo))
                        {
                            throw new Exception($"No existe el socio de negocios {scodigo}");
                        }
                        sDescripcion = sboDatoMaestroSocioNegocios.CardName;

                        break;
                    default:
                        throw new Exception($"El tipo de codigo{sTipoObjeto}");
                }
                return sDescripcion;
            }
            catch (Exception ex)
            {
                return $"Error {ex.Message}";
            }
        }
        public int ActualizarDatoMaestro(string sTipoObjeto, string scodigo, string sDescripcion)
        {
            int iCodigoError;
            Items sboDatoMaestroArticulo;// dato maestro del articulo
            BusinessPartners sboDatoMaestroSocioNegocios;//datos maestros del socio de negocios
            try
            {
                switch (sTipoObjeto)
                {
                    case "Articulo":
                        sboDatoMaestroArticulo = sboConexionDI.GetBusinessObject(BoObjectTypes.oItems);
                        //buscar el articulo RG221850
                        if (!sboDatoMaestroArticulo.GetByKey(scodigo))
                        {
                            throw new Exception($"No existe el articulo {scodigo}");
                        }
                        //Actualizar el registro
                        sboDatoMaestroArticulo.ItemName = sDescripcion;
                        iCodigoError = sboDatoMaestroArticulo.Update();
                        break;
                    case "Socio de negocio":
                        sboDatoMaestroSocioNegocios = sboConexionDI.GetBusinessObject(BoObjectTypes.oBusinessPartners);

                        if (!sboDatoMaestroSocioNegocios.GetByKey(scodigo))
                        {
                            throw new Exception($"No existe el socio de negocios {scodigo}");
                        }
                        sboDatoMaestroSocioNegocios.CardName = sDescripcion;
                        iCodigoError = sboDatoMaestroSocioNegocios.Update();

                        break;
                    default:
                        throw new Exception($"El tipo de codigo{sTipoObjeto}");
                }
                return iCodigoError;

            }
            catch (Exception ex)
            {
                return -1;
            }
        }

        public CICO.document RecuperarDocumento(string sTipoObjeto, string sCodigo)
        {
            Documents sboDocumento;
            CICO.document oDocumento;
            CICO.documentLine oLineaDocumento;
            try
            {
                switch (sTipoObjeto)
                {
                    case "Factura":
                        sboDocumento = sboConexionDI.GetBusinessObject(BoObjectTypes.oInvoices);
                        break;
                    case "Orden de Venta":
                        sboDocumento = sboConexionDI.GetBusinessObject(BoObjectTypes.oOrders);
                        break;
                    default:
                        throw new Exception($"El tipo de documento {sTipoObjeto} no esta soportado en esta version");
                }
                //Busqueda de docuemto

                if (!sboDocumento.GetByKey(Convert.ToInt32(sCodigo)))
                {
                    throw new Exception($"No existe el documento {sCodigo}");
                }
                oDocumento = new CICO.document();

                oDocumento.DocEntry = sboDocumento.DocEntry;
                oDocumento.DocNum = sboDocumento.DocNum;
                oDocumento.FechaVencimiento = sboDocumento.DocDueDate;
                oDocumento.comentarios = sboDocumento.Comments;

                oDocumento.CamposUsuarios = new Dictionary<string, object>();
                oDocumento.CamposUsuarios.Add("U_FECH_4", sboDocumento.UserFields.Fields.Item("U_FECH_4").Value);


                //se debe instanciar la lista.
                oDocumento.lineas = new List<CICO.documentLine>();

                for (int iIndiceDocumentos = 0; iIndiceDocumentos < sboDocumento.Lines.Count; iIndiceDocumentos++)
                {
                    sboDocumento.Lines.SetCurrentLine(iIndiceDocumentos);
                    oLineaDocumento = new CICO.documentLine();
                    oLineaDocumento.DocEntry = sboDocumento.Lines.DocEntry;
                    oLineaDocumento.LineNum = sboDocumento.Lines.LineNum;
                    oLineaDocumento.ItemCode = sboDocumento.Lines.ItemCode;
                    oLineaDocumento.ItemDescription = sboDocumento.Lines.ItemDescription;

                    oDocumento.lineas.Add(oLineaDocumento);
                }

                return oDocumento;
            }
            catch (Exception ex)
            {
                oDocumento = new CICO.document();
                oDocumento.error = ex.Message;
                return oDocumento;
            }
        }

        public int ActualizarDocumento(string sTipoObjeto, ref CICO.document oDocumento)
        {
            int iCodigoError;
            Documents sboDocumento;
            try
            {
                if (oDocumento == null)
                {
                    oDocumento = new CICO.document();
                    throw new Exception($"El objeto no puede ser null");
                }
                switch (sTipoObjeto)
                {
                    case "Factura":
                        sboDocumento = sboConexionDI.GetBusinessObject(BoObjectTypes.oInvoices);
                        break;
                    case "Orden de Venta":
                        sboDocumento = sboConexionDI.GetBusinessObject(BoObjectTypes.oOrders);
                        break;
                    default:
                        throw new Exception($"El tipo de documento {sTipoObjeto} no esta soportado en esta version");
                }
                //recuperar registro

                if (!sboDocumento.GetByKey(oDocumento.DocEntry))
                {
                    throw new Exception($"No se logro recuperar el documento {oDocumento.DocNum}({oDocumento.DocEntry}): {RecuperrarErrorSBO()}");
                }
                sboDocumento.Comments = oDocumento.comentarios;
                sboDocumento.DocDueDate = oDocumento.FechaVencimiento;

                foreach (var sCampoUsuario in oDocumento.CamposUsuarios)
                {
                    sboDocumento.UserFields.Fields.Item(sCampoUsuario.Key).Value = sCampoUsuario.Value;
                }

                iCodigoError = sboDocumento.Update();

                if (iCodigoError != 0)
                {
                    oDocumento.error = RecuperrarErrorSBO();
                }

                return iCodigoError;

            }
            catch (Exception ex)
            {
                oDocumento.error = ex.Message;
                return -1;
            }
        }
        public int CrearDocumento(string sTipoObjeto, ref CICO.document oDocumento)
        {
            int iCodigoError;
            Documents sboDocumento;
            try
            {
                if (oDocumento == null)
                {
                    oDocumento = new CICO.document();
                    throw new Exception($"El objeto no puede ser null");
                }
                switch (sTipoObjeto)
                {
                    case "Factura":
                        sboDocumento = sboConexionDI.GetBusinessObject(BoObjectTypes.oInvoices);
                        break;
                    case "Orden de Venta":
                        sboDocumento = sboConexionDI.GetBusinessObject(BoObjectTypes.oOrders);
                        break;
                    default:
                        throw new Exception($"El tipo de documento {sTipoObjeto} no esta soportado en esta version");
                }

                sboDocumento.CardCode = oDocumento.CardCode;
                sboDocumento.Comments = oDocumento.comentarios;
                sboDocumento.DocDate = oDocumento.DocDate;
                sboDocumento.DocDueDate = oDocumento.FechaVencimiento;

                foreach (var sCampoUsuario in oDocumento.CamposUsuarios)
                {
                    sboDocumento.UserFields.Fields.Item(sCampoUsuario.Key).Value = sCampoUsuario.Value;
                }

                foreach (CICO.documentLine olinea in oDocumento.lineas)
                {
                    sboDocumento.Lines.ItemCode = olinea.ItemCode;
                    sboDocumento.Lines.ItemDescription = olinea.ItemDescription;
                    sboDocumento.Lines.Quantity = olinea.Quantity;
                    sboDocumento.Lines.UnitPrice = olinea.UnitPrice;
                    sboDocumento.Lines.WarehouseCode = olinea.Almacen;
                    sboDocumento.Lines.TaxCode = olinea.TaxCode;

                    //sboDocumento.Lines.BatchNumbers.add SI ES GESTIONADO POR SERIE O LOTE


                    sboDocumento.Lines.Add();
                }

                iCodigoError = sboDocumento.Add();

                if (iCodigoError != 0)
                {
                    oDocumento.error = RecuperrarErrorSBO();
                }

                return iCodigoError;

            }
            catch (Exception ex)
            {
                oDocumento.error = ex.Message;
                return -1;
            }
        }
        //public Recordset GeneraConsulta(string sConsulta, out string sError) 
        //{
        //    Recordset sboConsulta;
        //    try 
        //    {
        //        sError = string.Empty;
        //        sboConsulta = sboConexionDI.GetBusinessObject(BoObjectTypes.BoRecordset);

        //        sboConsulta.DoQuery(sConsulta);

        //        if (sboConsulta.RecordCount == 0) 
        //        {
        //            throw new Exception($"No se encontraron socios de negocios" );
        //        }

        //        return sboConsulta;
        //    }
        //    catch (Exception ex)
        //    { 
        //        sError = ex.Message;
        //        return null; 
        //    }
        //}
        public List<Dictionary<string, object>> GeneraConsulta(string sConsulta, out string sError)
        {
            Recordset sboConsulta;
            List<Dictionary<string, object>> lResultado;
            try
            {

                sError = string.Empty;
                sboConsulta = sboConexionDI.GetBusinessObject(BoObjectTypes.BoRecordset);

                sboConsulta.DoQuery(sConsulta);

                lResultado = new List<Dictionary<string, object>>();

                if (sboConsulta.RecordCount == 0)
                {
                    return lResultado;
                }
                sboConsulta.MoveFirst();
                while (!sboConsulta.EoF)
                {
                    Dictionary<string, object> dFilaActual = new Dictionary<string, object>();

                    for (int iIndiceColumna = 0; iIndiceColumna < sboConsulta.Fields.Count; iIndiceColumna++)
                    {
                        dFilaActual.Add(sboConsulta.Fields.Item(iIndiceColumna).Name, sboConsulta.Fields.Item(iIndiceColumna).Value);
                    }
                    lResultado.Add(dFilaActual);
                    sboConsulta.MoveNext();
                }

                return lResultado;
            }
            catch (Exception ex)
            {
                sError = ex.Message;
                return null;
            }
        }

        /*public List<documentLine> GeneraFactura(string sConsulta, out string sError)
        {


        }*/
    }
}
