﻿gusing System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConectorDIAPI.CICO
{
    public class document
    {
        public int DocEntry { get; set; }
        public int DocNum { get; set; }
        public string CardCode { get; set; }    
        public string comentarios{get;  set;}//Coments 
        public DateTime DocDate { get; set; }
        public DateTime FechaVencimiento { get; set; }
        public List<documentLine> lineas { get; set; }
        public Dictionary<string, object> CamposUsuarios { get; set; }
        public string error { get; set; } 
    }
    public class documentLine
    { 
        public int DocEntry { get; set; }
        public int LineNum { get; set; }
        public string ItemCode { get; set; }    
        public string ItemDescription { get; set; } 
        public double Quantity { get; set; }
        public double UnitPrice { get; set;}
        public string UomCode { get; set;}
        public string Almacen { get; set;}
        public string TaxCode {get; set;}   

    }
}
