﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConectorDIAPI;
using System.Configuration;


namespace fechas
{
    public partial class Form1 : Form
    {
        private Conector oSociedad;
        public Form1()
        {
            InitializeComponent();
            conectar();
            llenaFactura();
        }
        private void conectar() {
            int iCodigoError;
            try
            {
                oSociedad = new Conector();

                iCodigoError = oSociedad.ConectarDI(ConfigurationManager.AppSettings["TipoServidor"],
                    ConfigurationManager.AppSettings["Servidor"],
                    ConfigurationManager.AppSettings["ServidorSLD"],
                    ConfigurationManager.AppSettings["ServidorLicencia"],
                    ConfigurationManager.AppSettings["BaseDatos"],
                    ConfigurationManager.AppSettings["UsuarioSAP"],
                    ConfigurationManager.AppSettings["PasswordSAP"],
                    ConfigurationManager.AppSettings["UsuarioBD"],
                    ConfigurationManager.AppSettings["PasswordBD"]);

                if (iCodigoError != 0)
                {
                    tbMensajes.AppendText($"Ocurrio un error de conexion {oSociedad.RecuperrarErrorSBO()}");
                }
                else
                {
                    tbMensajes.AppendText($"Conexion Exitosa ");
                }
            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error de conexion {ex.Message}");
            }
        }
        public void llenaFactura() 
        { 
            cbFactura.Items.Clear();
            cbFactura.Items.Add("hola");
        }
       
    }
}
