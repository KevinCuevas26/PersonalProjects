﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConectorDIAPI;
using ConectorDIAPI.CICO;
using System.Configuration;


namespace Manipulacion_de_documentos2
{
    public partial class Form1 : Form
    {
        private Conector oSociedad;
        public Form1()
        {
            InitializeComponent();
            conectar();
        }
        private void conectar() {
            int iCodigoError;
            try
            {
                oSociedad = new Conector();

                iCodigoError = oSociedad.ConectarDI(ConfigurationManager.AppSettings["TipoServidor"],
                    ConfigurationManager.AppSettings["Servidor"],
                    ConfigurationManager.AppSettings["ServidorSLD"],
                    ConfigurationManager.AppSettings["ServidorLicencia"],
                    ConfigurationManager.AppSettings["BaseDatos"],
                    ConfigurationManager.AppSettings["UsuarioSAP"],
                    ConfigurationManager.AppSettings["PasswordSAP"],
                    ConfigurationManager.AppSettings["UsuarioBD"],
                    ConfigurationManager.AppSettings["PasswordBD"]);

                if (iCodigoError != 0)
                {
                    tbMensajes.AppendText($"Ocurrio un error de conexion {oSociedad.RecuperrarErrorSBO()}");
                }
                else
                {
                    tbMensajes.AppendText($"Conexion Exitosa ");
                }
            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error de conexion {ex.Message}");
            }
        }
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            document oDocumento;
            try
            {
                //Valida Si esta Conectado
                if (!oSociedad.ValidaDIConectado())
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Conecte a la BD");
                    return;
                }
                if (cbTipoObjeto.SelectedItem == null)
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Seleccione tipo de dato a buscar");
                    return;
                }
                if (tbCodigo.Text == string.Empty)
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Ingrese Codigo");
                    return;
                }

                tbMensajes.AppendText($"{Environment.NewLine} Googleado wait a second");

                oDocumento = oSociedad.RecuperarDocumento(cbTipoObjeto.SelectedItem.ToString(), tbCodigo.Text);
                if (oDocumento.error!=null && oDocumento.error!=string.Empty) 
                {
                    tbMensajes.AppendText($"Ocurrio un error al buscar el documento {tbCodigo.Text}: {oDocumento.error}");
                    return;
                }

                tbComentarios.Text = oDocumento.comentarios;
                dtVencimiento.Value = oDocumento.FechaVencimiento;
                dtRevision.Value = (DateTime)oDocumento.CamposUsuarios["U_FECH_4"];
                
            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error al buscar {ex.Message}");

            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            int iCodigoError;
            document oDocumento;
            try 
            {
                if (!oSociedad.ValidaDIConectado())
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Conecte a la BD");
                    return;
                }
                if (cbTipoObjeto.SelectedItem == null)
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Seleccione tipo de dato a buscar");
                    return;
                }
                if (tbCodigo.Text == string.Empty)
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Ingrese Codigo");
                    return;
                }
                tbMensajes.AppendText($"{Environment.NewLine} Actualizanding wait a second.....");

                oDocumento=new document();  
                oDocumento.DocEntry=Convert.ToInt32(tbCodigo.Text);
                oDocumento.DocNum = Convert.ToInt32(tbCodigo.Text);
                oDocumento.comentarios=tbComentarios.Text;
                oDocumento.FechaVencimiento = dtVencimiento.Value;

                oDocumento.CamposUsuarios = new Dictionary<string, object>();
                oDocumento.CamposUsuarios.Add("U_FECH_4",dtRevision.Value);

                iCodigoError = oSociedad.ActualizarDocumento(cbTipoObjeto.SelectedItem.ToString(),ref oDocumento);

                if (iCodigoError != 0) 
                { 
                    tbMensajes.AppendText($"{Environment.NewLine} Error al Actualizar el Documento {oDocumento.DocNum}:{oDocumento.error}");
                    return;
                }
                tbMensajes.AppendText($"{Environment.NewLine} Documento actualizado con exito!!! :)");

            }
            catch (Exception ex) { 
                tbMensajes.AppendText($"{Environment.NewLine} Error al actualizar el documento {ex.Message}");
            }
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            int iCodigoError;
            document oDocumento;
            documentLine oLineaDocumento;
            try
            {
                if (!oSociedad.ValidaDIConectado())
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Conecte a la BD");
                    return;
                }
                if (cbTipoObjeto.SelectedItem == null)
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Seleccione tipo de dato a buscar");
                    return;
                }
                if (tbSocio.Text == string.Empty)
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Agrege Socio de Negocios");
                    return;
                }

                tbMensajes.AppendText($"{Environment.NewLine} Creating wait a second.....");

                oDocumento = new document();

                oDocumento.CardCode = tbSocio.Text;
                oDocumento.comentarios=tbComentarios.Text;
                oDocumento.DocDate = dtFechaContabilizacion.Value;
                oDocumento.FechaVencimiento=dtVencimiento.Value;

                oDocumento.CamposUsuarios = new Dictionary<string, object>();
                oDocumento.CamposUsuarios.Add("U_FECH_4",dtRevision.Value);

                oDocumento.lineas = new List<documentLine>();

                for(int iFila = 0;iFila<gdLineas.RowCount-1;iFila++) 
                {
                    oLineaDocumento = new documentLine();

                    oLineaDocumento.ItemCode = gdLineas.Rows[iFila].Cells["ItemCode"].Value.ToString();
                    oLineaDocumento.ItemDescription = gdLineas.Rows[iFila].Cells["ItemDescription"].Value.ToString();
                    oLineaDocumento.Quantity = Convert.ToDouble(gdLineas.Rows[iFila].Cells["Quantity"].Value);
                    oLineaDocumento.UnitPrice = Convert.ToDouble(gdLineas.Rows[iFila].Cells["UnitPrice"].Value);
                    oLineaDocumento.Almacen = gdLineas.Rows[iFila].Cells["almacen"].Value.ToString();
                    oLineaDocumento.TaxCode = gdLineas.Rows[iFila].Cells["TaxCode"].Value.ToString();

                    oDocumento.lineas.Add(oLineaDocumento);
                }

                iCodigoError = oSociedad.CrearDocumento(cbTipoObjeto.SelectedItem.ToString(), ref oDocumento);

                if (iCodigoError != 0)
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Error al Crear el Documento {oDocumento.DocNum}:{oDocumento.error}");
                    return;
                }
                tbMensajes.AppendText($"{Environment.NewLine} Documento Creado con exito!!! :)");

            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error al crear el documento {ex.Message}");
            }
        }
    }
}
