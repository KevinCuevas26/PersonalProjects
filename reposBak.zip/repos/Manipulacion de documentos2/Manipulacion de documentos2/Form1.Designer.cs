﻿namespace Manipulacion_de_documentos2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cbTipoObjeto = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbCodigo = new System.Windows.Forms.TextBox();
            this.tbComentarios = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbMensajes = new System.Windows.Forms.TextBox();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dtVencimiento = new System.Windows.Forms.DateTimePicker();
            this.dtRevision = new System.Windows.Forms.DateTimePicker();
            this.gdLineas = new System.Windows.Forms.DataGridView();
            this.btnCrear = new System.Windows.Forms.Button();
            this.dtFechaContabilizacion = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.tbSocio = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.LineNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.almacen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TaxCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.gdLineas)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tipo de Documento";
            // 
            // cbTipoObjeto
            // 
            this.cbTipoObjeto.FormattingEnabled = true;
            this.cbTipoObjeto.Items.AddRange(new object[] {
            "Factura",
            "Orden de Venta"});
            this.cbTipoObjeto.Location = new System.Drawing.Point(216, 79);
            this.cbTipoObjeto.Name = "cbTipoObjeto";
            this.cbTipoObjeto.Size = new System.Drawing.Size(159, 28);
            this.cbTipoObjeto.TabIndex = 1;
            this.cbTipoObjeto.Text = "Seleccione";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Codigo de Documento";
            // 
            // tbCodigo
            // 
            this.tbCodigo.Location = new System.Drawing.Point(216, 128);
            this.tbCodigo.Name = "tbCodigo";
            this.tbCodigo.Size = new System.Drawing.Size(159, 26);
            this.tbCodigo.TabIndex = 3;
            // 
            // tbComentarios
            // 
            this.tbComentarios.Location = new System.Drawing.Point(216, 182);
            this.tbComentarios.Multiline = true;
            this.tbComentarios.Name = "tbComentarios";
            this.tbComentarios.Size = new System.Drawing.Size(549, 124);
            this.tbComentarios.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 182);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Comentarios";
            // 
            // tbMensajes
            // 
            this.tbMensajes.Location = new System.Drawing.Point(16, 496);
            this.tbMensajes.Multiline = true;
            this.tbMensajes.Name = "tbMensajes";
            this.tbMensajes.Size = new System.Drawing.Size(602, 80);
            this.tbMensajes.TabIndex = 6;
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(445, 29);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(133, 33);
            this.btnBuscar.TabIndex = 7;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // btnActualizar
            // 
            this.btnActualizar.Location = new System.Drawing.Point(445, 71);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(133, 33);
            this.btnActualizar.TabIndex = 8;
            this.btnActualizar.Text = "Actualizar";
            this.btnActualizar.UseVisualStyleBackColor = true;
            this.btnActualizar.Click += new System.EventHandler(this.btnActualizar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(597, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Fecha de Vencimiento";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(597, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "Fecha de Revision";
            // 
            // dtVencimiento
            // 
            this.dtVencimiento.Location = new System.Drawing.Point(777, 40);
            this.dtVencimiento.Name = "dtVencimiento";
            this.dtVencimiento.Size = new System.Drawing.Size(200, 26);
            this.dtVencimiento.TabIndex = 13;
            // 
            // dtRevision
            // 
            this.dtRevision.Location = new System.Drawing.Point(777, 76);
            this.dtRevision.Name = "dtRevision";
            this.dtRevision.Size = new System.Drawing.Size(200, 26);
            this.dtRevision.TabIndex = 14;
            // 
            // gdLineas
            // 
            this.gdLineas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdLineas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.LineNum,
            this.ItemCode,
            this.ItemDescription,
            this.Quantity,
            this.UnitPrice,
            this.almacen,
            this.TaxCode});
            this.gdLineas.Location = new System.Drawing.Point(12, 330);
            this.gdLineas.Name = "gdLineas";
            this.gdLineas.RowHeadersWidth = 62;
            this.gdLineas.RowTemplate.Height = 28;
            this.gdLineas.Size = new System.Drawing.Size(965, 132);
            this.gdLineas.TabIndex = 15;
            // 
            // btnCrear
            // 
            this.btnCrear.Location = new System.Drawing.Point(799, 141);
            this.btnCrear.Name = "btnCrear";
            this.btnCrear.Size = new System.Drawing.Size(160, 55);
            this.btnCrear.TabIndex = 16;
            this.btnCrear.Text = "Crear";
            this.btnCrear.UseVisualStyleBackColor = true;
            this.btnCrear.Click += new System.EventHandler(this.btnCrear_Click);
            // 
            // dtFechaContabilizacion
            // 
            this.dtFechaContabilizacion.Location = new System.Drawing.Point(777, 3);
            this.dtFechaContabilizacion.Name = "dtFechaContabilizacion";
            this.dtFechaContabilizacion.Size = new System.Drawing.Size(200, 26);
            this.dtFechaContabilizacion.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(578, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(187, 20);
            this.label6.TabIndex = 17;
            this.label6.Text = "Fecha de Contabilizacion";
            // 
            // tbSocio
            // 
            this.tbSocio.Location = new System.Drawing.Point(216, 23);
            this.tbSocio.Name = "tbSocio";
            this.tbSocio.Size = new System.Drawing.Size(159, 26);
            this.tbSocio.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 20);
            this.label7.TabIndex = 19;
            this.label7.Text = "Cliente";
            // 
            // LineNum
            // 
            this.LineNum.HeaderText = "Linea";
            this.LineNum.MinimumWidth = 8;
            this.LineNum.Name = "LineNum";
            this.LineNum.Width = 150;
            // 
            // ItemCode
            // 
            this.ItemCode.HeaderText = "Articulo";
            this.ItemCode.MinimumWidth = 8;
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.Width = 150;
            // 
            // ItemDescription
            // 
            this.ItemDescription.HeaderText = "Descripcion ";
            this.ItemDescription.MinimumWidth = 8;
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.Width = 150;
            // 
            // Quantity
            // 
            this.Quantity.HeaderText = "Cantidad";
            this.Quantity.MinimumWidth = 8;
            this.Quantity.Name = "Quantity";
            this.Quantity.Width = 150;
            // 
            // UnitPrice
            // 
            this.UnitPrice.HeaderText = "Precio Unitario";
            this.UnitPrice.MinimumWidth = 8;
            this.UnitPrice.Name = "UnitPrice";
            this.UnitPrice.Width = 150;
            // 
            // almacen
            // 
            this.almacen.HeaderText = "Almacen";
            this.almacen.MinimumWidth = 8;
            this.almacen.Name = "almacen";
            this.almacen.Width = 150;
            // 
            // TaxCode
            // 
            this.TaxCode.HeaderText = "TaxCode";
            this.TaxCode.MinimumWidth = 8;
            this.TaxCode.Name = "TaxCode";
            this.TaxCode.Width = 150;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(986, 626);
            this.Controls.Add(this.tbSocio);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dtFechaContabilizacion);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnCrear);
            this.Controls.Add(this.gdLineas);
            this.Controls.Add(this.dtRevision);
            this.Controls.Add(this.dtVencimiento);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnActualizar);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.tbMensajes);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbComentarios);
            this.Controls.Add(this.tbCodigo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbTipoObjeto);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.gdLineas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbTipoObjeto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbCodigo;
        private System.Windows.Forms.TextBox tbComentarios;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbMensajes;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtVencimiento;
        private System.Windows.Forms.DateTimePicker dtRevision;
        private System.Windows.Forms.DataGridView gdLineas;
        private System.Windows.Forms.Button btnCrear;
        private System.Windows.Forms.DateTimePicker dtFechaContabilizacion;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbSocio;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridViewTextBoxColumn LineNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn almacen;
        private System.Windows.Forms.DataGridViewTextBoxColumn TaxCode;
    }
}

