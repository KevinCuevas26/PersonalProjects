﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using ConectorDIAPI;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private Conector oSociedad = new Conector();
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void conectar() {
            
        }
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string sComentarios;
            string sTipoObjeto;
            string sCodigo;
            try
            {
                //Valida Si esta Conectado
                if (!oSociedad.ValidaDIConectado())
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Conecte a la BD");
                    return;
                }
                if (cbTipoObjeto.SelectedItem == null)
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Seleccione tipo de dato a buscar");
                    return;
                }
                if (tbCodigo.Text == string.Empty)
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Ingrese Codigo");
                    return;
                }

                tbMensajes.AppendText($"{Environment.NewLine} Googleado wait a second");

                sTipoObjeto = cbTipoObjeto.Text;
                sCodigo = tbCodigo.Text;

                sComentarios = oSociedad.RecuperarDocumento(sTipoObjeto,sCodigo);
                tbComentarios.Text = sComentarios;
            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error al desconectar {ex.Message}");

            }
        }

        private void btnConectar_Click(object sender, EventArgs e)
        {
            int iCodigoError;
            try
            {
                iCodigoError = oSociedad.ConectarDI(ConfigurationManager.AppSettings["TipoServidor"],
                    ConfigurationManager.AppSettings["Servidor"],
                    ConfigurationManager.AppSettings["ServidorSLD"],
                    ConfigurationManager.AppSettings["ServidorLicencia"],
                    ConfigurationManager.AppSettings["BaseDatos"],
                    ConfigurationManager.AppSettings["UsuarioSAP"],
                    ConfigurationManager.AppSettings["PasswordSAP"],
                    ConfigurationManager.AppSettings["UsuarioBD"],
                    ConfigurationManager.AppSettings["PasswordBD"]);

                if (iCodigoError != 0)
                {
                    tbMensajes.AppendText($"Ocurrio un error de conexion {oSociedad.RecuperrarErrorSBO()}");
                }
                else
                {
                    tbMensajes.AppendText($"Conexion Exitosa ");
                }
            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error de conexion {ex.Message}");
            }
        }
    }
}
