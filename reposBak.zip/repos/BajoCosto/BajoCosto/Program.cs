﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConectorSap;
using SAPbobsCOM;
namespace BajoCosto
{
    internal class Program
    {
        private Mail oMail;
        static void Main(string[] args)
        {
            Program pr = new Program();
            pr.conectar();
            pr.recuperaBajoCosto();
            pr.desconecta();
        }
        public void conectar()
        {
            int iCodigoError;
            try
            {
                oMail = new Mail();

                iCodigoError = oMail.ConectarDI(ConfigurationManager.AppSettings["TipoServidor"],
                    ConfigurationManager.AppSettings["Servidor"],
                    ConfigurationManager.AppSettings["ServidorSLD"],
                    ConfigurationManager.AppSettings["ServidorLicencia"],
                    ConfigurationManager.AppSettings["BaseDatos"],
                    ConfigurationManager.AppSettings["UsuarioSAP"],
                    ConfigurationManager.AppSettings["PasswordSAP"],
                    ConfigurationManager.AppSettings["UsuarioBD"],
                    ConfigurationManager.AppSettings["PasswordBD"]);

                if (iCodigoError != 0)
                {
                    Console.WriteLine($"Ocurrio un error de conexion {oMail.RecuperrarErrorSBO()}");
                    return;
                }
                else
                {
                    Console.WriteLine($"Conexion Exitosa a Productivo ");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{Environment.NewLine} Error de conexion {ex.Message}");
                return;
            }
        }
        public void desconecta()
        {
            try
            {
                oMail.DesconectarDI();
                Console.WriteLine($"{Environment.NewLine} Desconexion exitosa");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{Environment.NewLine} Error al desconectar {ex.Message}");

            }
        }
        public void recuperaBajoCosto() 
        {
            string fecha = DateTime.Now.ToString("yyyy/MM/dd");
            string sConsultaCosto;
            int iDocEntry;
            int iBaseLine;
            int iDocNum;
            string sItemCode;
            string SCode;
            string slpName;
            string SName;
            double dPrecio;
            double dCosto;
            string sMoneda;
            string dCambio="";
            double dif;
            sConsultaCosto = "SELECT T0.DocEntry,T0.DocNum,T1.ItemCode,T1.BaseLine,T0.CardCode,T0.CardName,T2.SlpName,T1.Price,T1.GrossBuyPr AS 'COSTO',T1.Currency,T0.DocRate," +
                "(T1.GrossBuyPr-CASE WHEN T1.Currency='USD' THEN T0.DocRate*T1.Price WHEN T1.Currency='MXN' THEN T1.Price END) AS 'DIF' FROM OINV T0 INNER JOIN INV1 T1 ON T0.DocEntry=T1.DocEntry " +
                "INNER JOIN OSLP T2 ON T1.SlpCode=T2.SlpCode WHERE  T0.DocDate=CONVERT (date, GETDATE()) AND T0.Canceled='N' AND T1.Price!='0' AND  T1.GrossBuyPr>=CASE WHEN T1.Currency='USD' THEN T0.DocRate*T1.Price WHEN T1.Currency='MXN' THEN T1.Price END AND T0.DocDate=CONVERT (date, GETDATE()) AND " +
                "T0.DocTime BETWEEN concat(DATEPART(HOUR,DATEADD(HH,-1,GETDATE())),'00') AND concat(DATEPART(HOUR,GETDATE()),'00') ORDER BY T0.DocEntry DESC";
                /*sConsultaCosto = "SELECT T0.DocEntry,T0.DocNum,T1.ItemCode,T1.BaseLine,T0.CardCode,T0.CardName,T2.SlpName,T1.Price,T1.GrossBuyPr AS 'COSTO',T1.Currency,T0.DocRate,(T1.GrossBuyPr-CASE WHEN T1.Currency='USD' THEN T0.DocRate*T1.Price WHEN T1.Currency='MXN' THEN T1.Price END) AS 'DIF' " +
                "FROM OINV T0 INNER JOIN INV1 T1 ON T0.DocEntry=T1.DocEntry INNER JOIN OSLP T2 ON T1.SlpCode=T2.SlpCode WHERE  T0.DocDate='2023-10-16' AND T0.Canceled='N' AND T1.Price!='0' AND  T1.GrossBuyPr>= CASE WHEN T1.Currency='USD' THEN T0.DocRate*T1.Price WHEN T1.Currency='MXN' THEN T1.Price END AND T0.DocDate='2023-10-16'  ORDER BY T0.DocEntry DESC";*/
            SAPbobsCOM.Recordset sboResultadoCosto;
            string sError;
            string subject;
            string body;
            sboResultadoCosto = oMail.GeneraConsulta(sConsultaCosto, out sError);
            if (sError != string.Empty)
            {
                Console.WriteLine($"{Environment.NewLine} Error al Buscar {sError}");
                return;
            }
            for(int i = 0;i<sboResultadoCosto.RecordCount;i++) 
            {
                iDocEntry = sboResultadoCosto.Fields.Item("DocEntry").Value;
                iBaseLine = sboResultadoCosto.Fields.Item("BaseLine").Value+1;
                iDocNum = sboResultadoCosto.Fields.Item("DocNum").Value;
                sItemCode = sboResultadoCosto.Fields.Item("ItemCode").Value;
                SCode = sboResultadoCosto.Fields.Item("CardCode").Value;
                SName = sboResultadoCosto.Fields.Item("CardName").Value;
                slpName = sboResultadoCosto.Fields.Item("SlpName").Value;
                dPrecio = sboResultadoCosto.Fields.Item("Price").Value;
                dCosto = sboResultadoCosto.Fields.Item("COSTO").Value;
                sMoneda = sboResultadoCosto.Fields.Item("Currency").Value;
                dif = sboResultadoCosto.Fields.Item("DIF").Value;
                if (sMoneda == "USD")
                {
                    dCambio = "<br>Tipo de Cambio: $" + sboResultadoCosto.Fields.Item("DocRate").Value;
                    dCosto = dCosto / sboResultadoCosto.Fields.Item("DocRate").Value;
                    dif = dif / sboResultadoCosto.Fields.Item("DocRate").Value;
                }
                subject = "BAJO COSTO";
                body = $"Buen dia se tiene una factura a bajo costo.<br>Cliente: {SCode}<br> {SName}<br>Factura: {iDocNum}<br>" +
                    $"Item: {sItemCode}<br>Numero de Partida: {iBaseLine}{dCambio}<br>Moneda: {sMoneda}<br>Precio: ${dPrecio} {sMoneda}<br>Costo: ${dCosto.ToString("N6")} {sMoneda}<br>Diferencia: ${dif.ToString("N6")} {sMoneda}<br>Vendedor: {slpName} ";
                oMail.enviaCorreo(subject, body, "jasantiago@cintascove.com");
                sboResultadoCosto.MoveNext();
            }
        }
    }
}
