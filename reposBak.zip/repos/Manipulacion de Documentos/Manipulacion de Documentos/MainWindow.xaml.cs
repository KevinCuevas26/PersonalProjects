﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using ConectorDIAPI;

namespace Manipulacion_de_Documentos
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Conector oSociedad = new Conector();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnConectar_Click(object sender, RoutedEventArgs e)
        {
            int iCodigoError;
            try
            {
                iCodigoError = oSociedad.ConectarDI(ConfigurationManager.AppSettings["TipoServidor"],
                    ConfigurationManager.AppSettings["Servidor"],
                    ConfigurationManager.AppSettings["ServidorSLD"],
                    ConfigurationManager.AppSettings["ServidorLicencia"],
                    ConfigurationManager.AppSettings["BaseDatos"],
                    ConfigurationManager.AppSettings["UsuarioSAP"],
                    ConfigurationManager.AppSettings["PasswordSAP"],
                    ConfigurationManager.AppSettings["UsuarioBD"],
                    ConfigurationManager.AppSettings["PasswordBD"]);

                if (iCodigoError != 0)
                {
                    tbMensajes.AppendText($"Ocurrio un error de conexion {oSociedad.RecuperrarErrorSBO()}");
                }
                else
                {
                    tbMensajes.AppendText($"Conexion Exitosa ");
                }
            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error de conexion {ex.Message}");
            }
        }

        private void btnDesconectar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                oSociedad.DesconectarDI();
                tbMensajes.AppendText($"{Environment.NewLine} Desconexion exitosa");
            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error al desconectar {ex.Message}");

            }
        }

        private void btnBuscar_Click(object sender, RoutedEventArgs e)
        {
            string sComentarios;
            try {
                //Valida Si esta Conectado
                if (!oSociedad.ValidaDIConectado())
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Conecte a la BD");
                    return;
                }
                if (cbTipoObjeto.SelectedItem == null)
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Seleccione tipo de dato a buscar");
                    return;
                }
                if (tbCodigo.Text == string.Empty)
                {
                    tbMensajes.AppendText($"{Environment.NewLine} Ingrese Codigo");
                    return;
                }

                tbMensajes.AppendText($"{Environment.NewLine} Googleado wait a second");

                sComentarios = oSociedad.RecuperarDocumento();
                tbComentarios.Text = sComentarios;
            }
            catch (Exception ex)
            {
                tbMensajes.AppendText($"{Environment.NewLine} Error al desconectar {ex.Message}");

            }
        }
    }
}
