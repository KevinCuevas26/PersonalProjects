﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SAPbobsCOM;

namespace ConectorDIAPI
{
    public class Conector
    {
        Company sboConexionDI= new Company();
        public int ConectarDI(string sTipoServidor, string sServidor, string sServidorSLD, string sServidorLicencias, string sBaseDatos, string sUsuarioSAP, string sPasswordSAP, string sUsuarioBD, string sPasswordBD)
        {
            int iCodigoError;
            try 
            {
                
                //agregando datos de conexion.
                sboConexionDI.DbServerType = (BoDataServerTypes)Enum.Parse(typeof(BoDataServerTypes), sTipoServidor);   //dst_MSSQL2017
                sboConexionDI.Server = sServidor;
                sboConexionDI.SLDServer = sServidorSLD;
                sboConexionDI.LicenseServer = sServidorLicencias;
                sboConexionDI.CompanyDB = sBaseDatos;
                sboConexionDI.UserName = sUsuarioSAP;
                sboConexionDI.Password = sPasswordSAP;
                sboConexionDI.DbUserName = sUsuarioBD;
                sboConexionDI.DbPassword = sPasswordBD;

                iCodigoError =sboConexionDI.Connect();
                return iCodigoError;
            }catch(Exception ex)
            {
                throw new Exception($"Error al conectar {ex.Message}");
            }
            
        }
        public string RecuperrarErrorSBO()
        {
            string sError;
            try { 
                sError = sboConexionDI.GetLastErrorDescription();
                return sError;
            }catch(Exception e) {
                return $"error al recuperar el erroe SBO {e.Message}";
            }
        }
        public void DesconectarDI()
        {
            try {
                if( sboConexionDI.Connected)
                    sboConexionDI.Disconnect();
            }
            catch(Exception e)
            {
                throw new Exception($"Ocurrio un error al desconectar: {e.Message}");
            }
        }

        public bool ValidaDIConectado() {
            try
            {
                return sboConexionDI.Connected;
            }
            catch (Exception e)
            {
                throw new Exception($"Ocurrio un error : {e.Message}");
            }
        }

        public string RecuperaDatoMaestro(string sTipoObjeto, string scodigo)
        {
            string sDescripcion;
            Items sboDatoMaestroArticulo;// dato maestro del articulo
            BusinessPartners sboDatoMaestroSocioNegocios;//datos maestros del socio de negocios
            try {
                switch (sTipoObjeto) {
                    case "Articulo":
                        sboDatoMaestroArticulo = sboConexionDI.GetBusinessObject(BoObjectTypes.oItems);
                        //buscar el articulo RG221850
                        if (!sboDatoMaestroArticulo.GetByKey(scodigo))
                        {
                            throw new Exception($"No existe el articulo {scodigo}");
                        }
                        sDescripcion = sboDatoMaestroArticulo.ItemName;
                    break;
                    case "Socio de negocio":
                        sboDatoMaestroSocioNegocios = sboConexionDI.GetBusinessObject(BoObjectTypes.oBusinessPartners);

                        if (!sboDatoMaestroSocioNegocios.GetByKey(scodigo))
                        { 
                            throw new Exception($"No existe el socio de negocios {scodigo}");
                        }
                        sDescripcion = sboDatoMaestroSocioNegocios.CardName;

                    break;
                    default:
                        throw new Exception($"El tipo de codigo{sTipoObjeto}");
                }
                return sDescripcion;
            }
            catch(Exception ex) {
                return $"Error {ex.Message}";
            }
        }
        public int ActualizarDatoMaestro(string sTipoObjeto, string scodigo, string sDescripcion) {
            int iCodigoError;
            Items sboDatoMaestroArticulo;// dato maestro del articulo
            BusinessPartners sboDatoMaestroSocioNegocios;//datos maestros del socio de negocios
            try {
                switch (sTipoObjeto)
                {
                    case "Articulo":
                        sboDatoMaestroArticulo = sboConexionDI.GetBusinessObject(BoObjectTypes.oItems);
                        //buscar el articulo RG221850
                        if (!sboDatoMaestroArticulo.GetByKey(scodigo))
                        {
                            throw new Exception($"No existe el articulo {scodigo}");
                        }
                        //Actualizar el registro
                        sboDatoMaestroArticulo.ItemName = sDescripcion;
                        iCodigoError = sboDatoMaestroArticulo.Update();
                        break;
                    case "Socio de negocio":
                        sboDatoMaestroSocioNegocios = sboConexionDI.GetBusinessObject(BoObjectTypes.oBusinessPartners);

                        if (!sboDatoMaestroSocioNegocios.GetByKey(scodigo))
                        {
                            throw new Exception($"No existe el socio de negocios {scodigo}");
                        }
                        sboDatoMaestroSocioNegocios.CardName= sDescripcion;
                        iCodigoError=sboDatoMaestroSocioNegocios.Update();

                        break;
                    default:
                        throw new Exception($"El tipo de codigo{sTipoObjeto}");
                }
                return iCodigoError;

            }
            catch (Exception ex)
            {
                return -1;
            }
        }

        public string RecuperarDocumento(string sTipoObjeto, string sCodigo) 
        {
            string sComentario;
            Documents sboDocumento;

            try {
                switch (sTipoObjeto) {
                    case "Factura":
                        sboDocumento = sboConexionDI.GetBusinessObject(BoObjectTypes.oInvoices);
                        break;
                    case "Orden de Venta":
                        sboDocumento = sboConexionDI.GetBusinessObject(BoObjectTypes.oOrders);
                        break;
                        default :
                        throw new Exception($"El tipo de documento {sTipoObjeto} no esta soportado en esta version");
                }
                //Busqueda de docuemto
                
                if (!sboDocumento.GetByKey(Convert.ToInt32(sCodigo))) {
                    throw new Exception($"No existe el documento {sCodigo}");
                }

                sComentario = sboDocumento.Comments;

                return sComentario;
            }
            catch (Exception ex)
            {
                return $"Error {ex.Message}";
            }
        }
    }
}
