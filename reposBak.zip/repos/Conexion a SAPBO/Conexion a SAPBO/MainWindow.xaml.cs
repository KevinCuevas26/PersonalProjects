﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ConectorDIAPI;
using System.Configuration;
namespace Conexion_a_SAPBO
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Conector oSociedad;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void bnConectar_Click(object sender, RoutedEventArgs e)
        {
            int iCodigoError;
            try
            {
                oSociedad = new Conector();

                iCodigoError=oSociedad.ConectarDI(ConfigurationManager.AppSettings["TipoServidor"], 
                    ConfigurationManager.AppSettings["Servidor"], 
                    ConfigurationManager.AppSettings["ServidorSLD"], 
                    ConfigurationManager.AppSettings["ServidorLicencia"], 
                    ConfigurationManager.AppSettings["BaseDatos"],
                    ConfigurationManager.AppSettings["UsuarioSAP"],
                    ConfigurationManager.AppSettings["PasswordSAP"],
                    ConfigurationManager.AppSettings["UsuarioBD"],
                    ConfigurationManager.AppSettings["PasswordBD"]);

                if (iCodigoError != 0) {
                    tbMensajes.AppendText($"Ocurrio un error de conexion {oSociedad.RecuperrarErrorSBO()}");
                }
                else {
                    tbMensajes.AppendText($"Conexion Exitosa ");
                }
            }
            catch (Exception ex) {
                tbMensajes.AppendText($"{Environment.NewLine} Error de conexion {ex.Message}");
            }
        }

        private void BTNDesconectar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                oSociedad.DesconectarDI();
                tbMensajes.AppendText($"{Environment.NewLine} Desconexion exitosa");
            }
            catch (Exception ex) { 
                tbMensajes.AppendText($"{Environment.NewLine} Error al desconectar {ex.Message}");
            
            }
        }
    }
}
