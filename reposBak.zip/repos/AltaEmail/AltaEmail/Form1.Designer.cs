﻿namespace AltaEmail
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbNom = new System.Windows.Forms.TextBox();
            this.tbAp = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cMasculino = new System.Windows.Forms.CheckBox();
            this.cFemenino = new System.Windows.Forms.CheckBox();
            this.cTcambio = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnGuarda = new System.Windows.Forms.Button();
            this.tbMsj = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 146);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ingrese Email:";
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(148, 140);
            this.tbEmail.MaxLength = 50;
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(297, 26);
            this.tbEmail.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ingrese Nombre:";
            // 
            // tbNom
            // 
            this.tbNom.Location = new System.Drawing.Point(148, 43);
            this.tbNom.MaxLength = 25;
            this.tbNom.Name = "tbNom";
            this.tbNom.Size = new System.Drawing.Size(297, 26);
            this.tbNom.TabIndex = 1;
            // 
            // tbAp
            // 
            this.tbAp.Location = new System.Drawing.Point(148, 89);
            this.tbAp.MaxLength = 25;
            this.tbAp.Name = "tbAp";
            this.tbAp.Size = new System.Drawing.Size(297, 26);
            this.tbAp.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Ingrese Apellido:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Sexo:";
            // 
            // cMasculino
            // 
            this.cMasculino.AutoSize = true;
            this.cMasculino.Location = new System.Drawing.Point(148, 196);
            this.cMasculino.Name = "cMasculino";
            this.cMasculino.Size = new System.Drawing.Size(106, 24);
            this.cMasculino.TabIndex = 4;
            this.cMasculino.Text = "Masculino";
            this.cMasculino.UseVisualStyleBackColor = true;
            this.cMasculino.CheckedChanged += new System.EventHandler(this.cMasculino_CheckedChanged);
            // 
            // cFemenino
            // 
            this.cFemenino.AutoSize = true;
            this.cFemenino.Location = new System.Drawing.Point(302, 196);
            this.cFemenino.Name = "cFemenino";
            this.cFemenino.Size = new System.Drawing.Size(106, 24);
            this.cFemenino.TabIndex = 5;
            this.cFemenino.Text = "Femenino";
            this.cFemenino.UseVisualStyleBackColor = true;
            this.cFemenino.CheckedChanged += new System.EventHandler(this.cFemenino_CheckedChanged);
            // 
            // cTcambio
            // 
            this.cTcambio.AutoSize = true;
            this.cTcambio.Location = new System.Drawing.Point(41, 273);
            this.cTcambio.Name = "cTcambio";
            this.cTcambio.Size = new System.Drawing.Size(145, 24);
            this.cTcambio.TabIndex = 6;
            this.cTcambio.Text = "Tipo de Cambio";
            this.cTcambio.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(243, 239);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Opciones:";
            // 
            // btnGuarda
            // 
            this.btnGuarda.Location = new System.Drawing.Point(517, 49);
            this.btnGuarda.Name = "btnGuarda";
            this.btnGuarda.Size = new System.Drawing.Size(110, 66);
            this.btnGuarda.TabIndex = 7;
            this.btnGuarda.Text = "Guardar";
            this.btnGuarda.UseVisualStyleBackColor = true;
            this.btnGuarda.Click += new System.EventHandler(this.btnGuarda_Click);
            // 
            // tbMsj
            // 
            this.tbMsj.Location = new System.Drawing.Point(-2, 358);
            this.tbMsj.Multiline = true;
            this.tbMsj.Name = "tbMsj";
            this.tbMsj.ReadOnly = true;
            this.tbMsj.Size = new System.Drawing.Size(679, 95);
            this.tbMsj.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 450);
            this.Controls.Add(this.tbMsj);
            this.Controls.Add(this.btnGuarda);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cTcambio);
            this.Controls.Add(this.cFemenino);
            this.Controls.Add(this.cMasculino);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbAp);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbNom);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbEmail);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Alta Email";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbNom;
        private System.Windows.Forms.TextBox tbAp;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox cMasculino;
        private System.Windows.Forms.CheckBox cFemenino;
        private System.Windows.Forms.CheckBox cTcambio;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnGuarda;
        private System.Windows.Forms.TextBox tbMsj;
    }
}

