﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConectorSap;

namespace AltaEmail
{
    public partial class Form1 : Form
    {
        private Conector oSociedad;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cMasculino_CheckedChanged(object sender, EventArgs e)
        {
            if (cMasculino.Checked) 
            {
                cFemenino.Checked = false;
                cFemenino.Enabled = false;
            }
            else 
            {
                cFemenino.Checked = false;
                cFemenino.Enabled = true;
            }
        }

        private void cFemenino_CheckedChanged(object sender, EventArgs e)
        {
            if (cFemenino.Checked)
            {
                cMasculino.Checked = false;
                cMasculino.Enabled = false;
            }
            else
            {
                cMasculino.Checked = false;
                cMasculino.Enabled = true;
            }
        }

        private void btnGuarda_Click(object sender, EventArgs e)
        {
            try
            {
                tbMsj.Text = "";
                string sNombre = tbNom.Text;
                valida(sNombre,"Nombre");
                string sApellido = tbAp.Text;
                valida(sApellido,"Apellido");
                string sEmail = tbEmail.Text;
                valida(sEmail, "Apellido");
                string sSexo="";
                string sCambio="";
                if (cMasculino.Checked)
                {
                    sSexo = "M";
                }
                if (cFemenino.Checked)
                {
                    sSexo = "F";
                }
                if (cTcambio.Checked)
                {
                    sCambio = "1";
                }
                valida(sSexo, "Sexo");

                conectar();
                int iCodigoError=oSociedad.altaEmail(sNombre,sApellido,sEmail,sSexo,sCambio);
                desconecta();
                if (iCodigoError != 0)
                {
                    tbMsj.Text=$"Ocurrio un error de al guardar {oSociedad.RecuperrarErrorSBO()}";
                    return;
                }
                else 
                {
                    tbMsj.Text=$"Registro Guardado con exito";
                    limpia();
                }
            }
            catch (Exception ex)
            {
                tbMsj.Text = $"{ex.Message}";
            }
        }
        public void conectar()
        {
            int iCodigoError;
            try
            {
                oSociedad = new Conector();

                iCodigoError = oSociedad.ConectarDI(ConfigurationManager.AppSettings["TipoServidor"],
                    ConfigurationManager.AppSettings["Servidor"],
                    ConfigurationManager.AppSettings["ServidorSLD"],
                    ConfigurationManager.AppSettings["ServidorLicencia"],
                    ConfigurationManager.AppSettings["BaseDatos"],
                    ConfigurationManager.AppSettings["UsuarioSAP"],
                    ConfigurationManager.AppSettings["PasswordSAP"],
                    ConfigurationManager.AppSettings["UsuarioBD"],
                    ConfigurationManager.AppSettings["PasswordBD"]);

                if (iCodigoError != 0)
                {
                    tbMsj.Text=($"Ocurrio un error de conexion {oSociedad.RecuperrarErrorSBO()}");
                    return;
                }
                else
                {
                    tbMsj.Text = ($"Conexion Exitosa a Productivo ");
                }
            }
            catch (Exception ex)
            {
                tbMsj.Text = ($"{Environment.NewLine} Error de conexion {ex.Message}");
                return;
            }
        }
        public void desconecta()
        {
            try
            {
                oSociedad.DesconectarDI();
                //tbMsj.Text = ($"{Environment.NewLine} Desconexion exitosa");
            }
            catch (Exception ex)
            {
                tbMsj.Text = ($"{Environment.NewLine} Error al desconectar {ex.Message}");

            }
        }
        public int valida(string sTexto,string sTipo) 
        {
            if (String.IsNullOrEmpty(sTexto)) 
            {
                throw new Exception($"Debe de llenar los datos en: {sTipo}");
            }
            return 1;
        }
        public void limpia()
        {
            tbNom.Text="";
            tbAp.Text="";
            tbEmail.Text = "";
            cMasculino.Checked = false;
            cMasculino.Enabled = true;
            cFemenino.Checked = false;
            cFemenino.Enabled = true;

        }
    }
}
