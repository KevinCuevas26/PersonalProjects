<?php
//error_reporting(E_ERROR | E_WARNING | E_PARSE);
//header('Content-Type: text/html; charset=utf-8');
date_default_timezone_set("America/Mexico_City");
//header("Cache-Control: no-store, no-cache, must-revalidate");
//header("Pragma: no-cache");
//date_default_timezone_set('America/Los_Angeles');
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_database = "192.168.123.10";
$username_database = "fgomez";
$password_database = "2022*ljgv"; 
$database_database = "cove";

$database = mysqli_connect ($hostname_database, $username_database, $password_database,$database_database) or trigger_error(mysqli_error(),E_USER_ERROR); 


?>