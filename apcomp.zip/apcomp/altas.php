<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>
    <link href="select2/select2.min.css" rel="stylesheet" />
    <script src="select2/select2.min.js"></script>
    <link rel="stylesheet" media="all" href="css/style.css" />
    <title>Catalogo de Insumos</title>
</head>
<body onload="opcionesAltas('1')">
<div class="centro">
    <h2 style="margin-left:32px">Catalogo de Insumos </h2>
    <nav class="tabbar">
            <div>
                <input id="menu-1" type="radio" name="menu" onclick="pestanaAltas(this)" value="1" checked>
                <label for="menu-1">
                    <svg>
                        <use xlink:href="#newIcon">
                    </svg>
                    <span>Clasificacion</span>
                </label>
                <input id="menu-2" type="radio" name="menu" onclick="pestanaAltas(this)" value="2">
                <label for="menu-2">
                    <svg>
                        <use xlink:href="#inprocessIcon">
                    </svg>
                    <span>Insumo</span>
                </label>
                <input id="menu-3" type="radio" name="menu" onclick="pestanaAltas(this)" value="3">
                <label for="menu-3">
                    <svg>
                        <use xlink:href="#finishIcon">
                    </svg>
                    <span>Concentrado</span>
                </label>
                <span></span>
            </div>
        </nav>

        <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
            <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" id="newIcon" fill="currentColor">
                <path d="M2.165 19.551c.186.28.499.449.835.449h15c.4 0 .762-.238.919-.606l3-7A.998.998 0 0 0 21 11h-1V8c0-1.103-.897-2-2-2h-6.655L8.789 4H4c-1.103 0-2 .897-2 2v13h.007a1 1 0 0 0 .158.551zM18 8v3H6c-.4 0-.762.238-.919.606L4 14.129V8h14z"></path>
            </symbol>
            <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" id="inprocessIcon" fill="currentColor">
                <path d="M21.993 7.95a.96.96 0 0 0-.029-.214c-.007-.025-.021-.049-.03-.074-.021-.057-.04-.113-.07-.165-.016-.027-.038-.049-.057-.075-.032-.045-.063-.091-.102-.13-.023-.022-.053-.04-.078-.061-.039-.032-.075-.067-.12-.094-.004-.003-.009-.003-.014-.006l-.008-.006-8.979-4.99a1.002 1.002 0 0 0-.97-.001l-9.021 4.99c-.003.003-.006.007-.011.01l-.01.004c-.035.02-.061.049-.094.073-.036.027-.074.051-.106.082-.03.031-.053.067-.079.102-.027.035-.057.066-.079.104-.026.043-.04.092-.059.139-.014.033-.032.064-.041.1a.975.975 0 0 0-.029.21c-.001.017-.007.032-.007.05V16c0 .363.197.698.515.874l8.978 4.987.001.001.002.001.02.011c.043.024.09.037.135.054.032.013.063.03.097.039a1.013 1.013 0 0 0 .506 0c.033-.009.064-.026.097-.039.045-.017.092-.029.135-.054l.02-.011.002-.001.001-.001 8.978-4.987c.316-.176.513-.511.513-.874V7.998c0-.017-.006-.031-.007-.048zm-10.021 3.922L5.058 8.005 7.82 6.477l6.834 3.905-2.682 1.49zm.048-7.719L18.941 8l-2.244 1.247-6.83-3.903 2.153-1.191zM13 19.301l.002-5.679L16 11.944V15l2-1v-3.175l2-1.119v5.705l-7 3.89z"></path>
            </symbol>
            <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" id="finishIcon" fill="currentColor">
                <path d="M21 5c0-1.103-.897-2-2-2H5c-1.103 0-2 .897-2 2v14c0 1.103.897 2 2 2h14c1.103 0 2-.897 2-2V5zM5 19V5h14l.002 14H5z"></path><path d="M7 7h1.998v2H7zm4 0h6v2h-6zm-4 4h1.998v2H7zm4 0h6v2h-6zm-4 4h1.998v2H7zm4 0h6v2h-6z"></path>
            </symbol>
        </svg>
</div>
        <section id="solicitud" name="solicitud">
        <iframe class="frame" id="frame" src="./php/solicitud.php" frameborder="0" height="100%" width="100%"></iframe>
    </section>
    
    
    <script type="text/javascript" src="js/opciones.js"></script>

</body>
</html>