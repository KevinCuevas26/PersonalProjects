<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" media="all" href="./../css/style.css" />
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
    <title>View</title>
</head>
<body onload="proceso(2)">
    <h2 class="titulo">Solicitudes en proceso</h2>
    <section class="proceso" id="proceso" name="proceso">
        <table>
            <thead>
                <tr class="primero">
                    <td>Folio</td>
                    <td>Solicita</td>
                    <td>Fecha de solicitud</td>
                    <td>Estatus</td>
                    <td>Btn view</td>
                </tr>
            </thead>
            <tbody name="cuerpo" id="cuerpo"></tbody>
        </table>
    </section>
    <script type="text/javascript" src="./../js/opciones.js"></script>
    
</body>
</html>