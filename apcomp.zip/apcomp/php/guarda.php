<?php 
    session_start();
    if(!isset($_SESSION['id'])){
        header("Location: ../index.php");
    }
    $id = $_SESSION['id'];
    require('../i_database.php');
    $fecha=date("Y-m-d H:i:s");
    $tipo=$_GET['tipo'];
    switch($tipo){
        case 1:
            $clasif=$_POST['clasif'];
            $soli=$_POST['soli'];
            $cAct = (isset($_POST['activo'])) ? '1' : '0';
            $cInac = (isset($_POST['baja'])) ? '1' : '0';
            if($cAct==0 && $cInac==0)
                $cAct=1;

            $sql="INSERT INTO `apcomp_clasificacion`(`folio`, `nombre`, `status`, `alta`, `fecha`,`depto`) 
            VALUES (null,'$clasif','$cAct','$id','$fecha','$soli')";
        break;
        case 2:
            $insumo=$_POST['insumo'];
            $clasifica=$_POST['clasifica'];
            $sql="INSERT INTO `apcomp_insumos`(`folio`, `insumo`, `clasificacion`,`fecha`,`alta`) 
            VALUES (null,'$insumo','$clasifica','$fecha','$id')";
        break;
    }
    $execute=mysqli_query($database,$sql);
    if($execute==1){
        echo "<script>alert('Registro Guardado con exito');
        location.href='./altaClasif.php';</script>";
    }
?>