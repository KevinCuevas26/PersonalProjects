<?php
    require('./../i_database.php');
    $sql="SELECT folio,nombre FROM apcomp_Clasificacion WHERE status=1";
    $resultado=mysqli_query($database,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" media="all" href="./../css/style.css" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
    <title>Alta Insumo</title>
</head>
<body>
<h2 class="titulo">Alta de Insumos</h2>

<section id="solicitud" name="solicitud">
    <form action="./guarda.php?tipo=2" method="POST">
    <table>
        <tr>
            <td>Insumo</td>
            <td><input type="text" id="insumo" name="insumo" placeholder="Ingrese Insumo" required /></td>
        </tr>
        <tr>
            <td>Clasificacion</td>
            <td>
                <select name="clasifica" id="clasifica">
                    <option value="">Seleccione...</option>
                <?php 
                 while($extra=mysqli_fetch_array($resultado)){
                    echo '<option value="'.$extra[0].'">'.$extra[1].'</option> ';
                 }   
                ?>
                </select>
            </td>
        </tr>
    </table>
    <input class="boton" style="margin-top:15px" type="submit" value="Aceptar">
    </from>
</section>
</body>
</html>