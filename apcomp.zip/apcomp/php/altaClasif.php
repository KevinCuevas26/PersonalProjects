<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" media="all" href="./../css/style.css" />
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
    <title>Alta Clasificacion</title>
</head>
<body>
<h2 class="titulo">Alta de Clasificacion</h2>

<section id="solicitud" name="solicitud">
    <form action="./guarda.php?tipo=1" method="POST">
    <table style="margin:0 auto">
        <thead>
            <tr>
                <td>Ingrese Clasificacion</td>
                <td>
                    <input type="text" id="clasif" name="clasif" placeholder="Clasificacion" required/>
                    <input type="button" value="Buscar" onclick="busClasif()">
                </td>
            </tr>
            <tr>
                <td>Status</td>
                <td><input type="checkbox" name="activo" id="activo" onchange="checka(this,1)"> Activo <input type="checkbox" name="baja" id="baja" onchange="checka(this,2)"> inactivo</td>
            </tr>
        </thead>
        <tbody id="tbody" name="tbody">
            <tr>
                <td>Quien solicita</td>
                <td>
                    <select name="soli" id="soli">
                        <option value="1">Direccion</option>
                        <option value="2">RRHH</option>
                        <option value="3">Calidad</option>
                        <option value="4">Maquila</option>
                        <option value="5">Almacen</option>
                        <option value="6">TI</option>
                        <option value="7">Finanzas</option>
                        <option value="8" selected>General</option>
                    </select>
                </td>
            </tr>
        </tbody>
    </table>
    <input class="boton" style="margin-top:15px" type="submit" value="Aceptar">
    </form>
</section>
    <script type="text/javascript" src="./../js/opciones.js"></script>

</body>
</html>