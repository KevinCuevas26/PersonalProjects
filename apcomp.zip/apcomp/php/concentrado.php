<?php
    require('./../i_database.php');
    $sql="SELECT T1.nombre,T0.insumo,T0.fecha,T2.Nombre FROM apcomp_insumos T0 
    INNER JOIN apcomp_clasificacion T1 ON T0.clasificacion=T1.folio
    INNER JOIN usuarios T2 ON T0.alta=T2.id_user";
    $resultado=mysqli_query($database,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" media="all" href="./../css/style.css" />
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
    <title>Concentrado</title>
</head>
<body>
<section id="solicitud" name="solicitud">
    <table>
        <tr>
            <td>Clasificacion</td>
            <td>Insumo</td>
            <td>Fecha de alta</td>
            <td>Quien dio alta</td>
        </tr>
        <?php 
        while($extra=mysqli_fetch_array($resultado)){
            echo '<tr>
                <td>'.$extra[0].'</td>
                <td>'.$extra[1].'</td>
                <td>'.$extra[2].'</td>
                <td>'.$extra[3].'</td>
            </tr>';
        }
        ?>
    </table>
</section>
</body>
</html>