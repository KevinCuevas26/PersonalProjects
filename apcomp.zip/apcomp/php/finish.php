<!DOCTYPE html>
<?php 
    session_start();
    $iduser = $_SESSION['id'];
    if($iduser==16 || $iduser==17 || $iduser==18){
        require('./../i_database.php');
        date_default_timezone_set('America/Mexico_City');
        $pagina=1;
        if(isset($_GET["val"])){
            $year=$_POST['anio'];
            $mes=$_POST['mes'];
        }
        $anioAct=date('Y');
        $anioAnt=$anioAct-1;
    }else{
        echo "<script>location.href='./../php/view.php';</script>";
    }
    
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" media="all" href="./../css/style.css" />
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
    <title>Finalizado</title>
</head>
<body>
    <form action="./finish.php?val=1" method="POST">
        <label>Seleccione Año:
            <select name="anio" id="anio">
                <option value="<?php echo $anioAct?>"><?php echo $anioAct?></option>
                <option value="<?php echo $anioAnt ?>"><?php echo $anioAnt ?></option>
            </select>
        </label>
        <label>Seleccione Mes:
            <select name="mes" id="mes">
                <option value="">Seleccione....</option>
                <option value="1">Enero</option>
                <option value="2">Febrero</option>
                <option value="3">Marzo</option>
                <option value="4">Abril</option>
                <option value="5">Mayo</option>
                <option value="6">Junio</option>
                <option value="7">Julio</option>
                <option value="8">Agosto</option>
                <option value="9">Septiembre</option>
                <option value="10">Octubre</option>
                <option value="11">Noviembre</option>
                <option value="12">Diciembre</option>
            </select>
        </label>
        <button>Aceptar</button>
    </form>
    <?php 
    if(isset($_GET["val"])){
        $year=$_POST['anio'];
        $mes=$_POST['mes'];
        $meses=["","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
        $where="";
        if($iduser=='17'||$iduser=='18')
            $where=" AND T0.comprador='$iduser'";
        $day = date("d", mktime(0,0,0, $mes+1, 0, $year));
        $lastDay=date('Y-m-d', mktime(0,0,0, $mes, $day, $year));
        $fristDay= date('Y-m-d', mktime(0,0,0, $mes, 1, $year));
        $sql="SELECT T0.folio,T0.fechasoli,T0.fecautoin,T0.fecautocomp,T0.fecter,T1.nombree,T2.Nombre AS 'NombreS',T3.Nombre,T4.descripcion,T0.fecautodir FROM apcomp_solicitudes T0 
        INNER JOIN empresa T1 ON T0.empresa=T1.folio
        INNER JOIN usuarios T2 ON T0.solicita=T2.id_user
        INNER JOIN usuarios T3 ON T0.COMPRADOR=T3.id_user
        INNER JOIN apcomp_estatus T4 ON T0.status=T4.folio
        WHERE T0.fechasoli BETWEEN '$fristDay' AND '$lastDay' $where ";
        $resultado=mysqli_query($database,$sql);
    ?>
    <h2>Reporte de Solicitudes realizadas el mes de <?php echo $meses[$mes] ?></h2>
    <section id="solicitud" name="solicitud">
        <table class="atv">
            <thead>
                <tr class="primero">
                    <td>Folio</td>
                    <td>Empresa</td>
                    <td>Solicita</td>
                    <td>Status</td>
                    <td>Fecha de solicitud</td>
                    <td>Fecha Autorizacion Jefe inmediato</td>
                    <td>Fecha Asignacion Ticket</td>
                    <td>Fecha Autorizacion Direccion</td>
                    <td>Fecha cierre Ticket</td><?php 
                    if($iduser=='16') { ?>
                    <td>Compradora</td>
                    <?php } ?>
                </tr>
            </thead>
            <tbody>
                <?php 
                while($extra=mysqli_fetch_array($resultado)){
                    echo "<tr>
                        <td>".$extra['folio']."</td>
                        <td>".$extra['nombree']."</td>
                        <td>".$extra['NombreS']."</td>
                        <td>".$extra['descripcion']."</td>
                        <td>".$extra['fechasoli']."</td>
                        <td>".$extra['fecautoin']."</td>
                        <td>".$extra['fecautocomp']."</td>
                        <td>".$extra['fecautodir']."</td>
                        <td>".$extra['fecter']."</td>";
                    if($iduser=='16'){
                        echo "<td>".$extra['Nombre']."</td>";
                    }   
                    echo "</tr>";
                }
                ?> 
            </tbody>
        </table>
    </section>
    <?php } ?>
</body>
</html>