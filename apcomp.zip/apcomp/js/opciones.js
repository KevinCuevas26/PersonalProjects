let carrito=[];
const DOMcarrito=document.querySelector('#cart');
const DOMbotonVaciar=document.querySelector('#boton-vaciar');

function cart(cantidad,idinsumo){
    this.cantidad=cantidad;
    this.idinsumo=idinsumo;
}

function addcart(){
    let clasif=document.getElementById('clasif').value;
    if(clasif==''){
        alert('Seleccione clasificacion');
        return;
    }
    let idinsumo=document.getElementById('insumo').value;
    if(idinsumo==''){
        alert('Seleccione Insumo');
        return;
    }
    let cant=document.getElementById('cant').value;
    let newart=new cart(cant,idinsumo);
    carrito.push(newart);
    mostrar();
    clasificacion();
    document.getElementById('ins').innerHTML="";
    document.getElementById('cant').value=1;

}

function mostrar(){
    //DOMcarrito.textContent="";
    document.getElementById('cart').innerHTML='';
    let i=0;
    let btn='btn'+i;
    let html='';
    carrito.forEach(p=>{
        html+='<tr><td>'+p.cantidad+'</td><td> '+p.idinsumo+'<td><button id="'+btn+'" value="'+i+'"onclick="borra(this)">X</button></td></td></tr>';
        i++;
    })
    document.getElementById('cart').innerHTML=html;

}

function resta(){
    let cantidad=document.getElementById('cant').value;
    if(cantidad==1){
        alert('La cantidad mimina es 1');
        return;
    }
    let resultado=cantidad-1;
    document.getElementById('cant').value=resultado;
}

function suma(){
    let cantidad=document.getElementById('cant').value;
    let resultado=parseInt(cantidad)+1;
    document.getElementById('cant').value=resultado;
}

function borra(btn){
    let valBtnIni=btn.value;
    carrito.splice(valBtnIni,1);
    mostrar();
}



function pestana(radio,pagina){
    let valor=radio.value;
    opciones(valor,pagina);
    
}
function opciones(valor,pagina){
    switch(valor){
        case 1:
            document.getElementById('solicitud').style.display='block';
            document.getElementById('solicitud').style.display='flex'; 
            if(pagina=1)  
                clasificacion();
        break;
        case '1':
            document.getElementById('solicitud').style.display='block';
            document.getElementById('solicitud').style.display='flex';  
            document.getElementById('frame').src='./php/solicitud.php';  
            
            if(pagina=1)  
                clasificacion();  
        break;
        case '2':
            document.getElementById('solicitud').style.display='block';
            document.getElementById('solicitud').style.display='flex';  
            document.getElementById('frame').src='./php/view.php';  
        break;
        case '3':
            document.getElementById('solicitud').style.display='block';
            document.getElementById('solicitud').style.display='flex';  
            document.getElementById('frame').src='./php/finish.php';  
        break;
    }
}
function opcionesAltas(valor){
    document.getElementById('solicitud').style.display='block';
    document.getElementById('solicitud').style.display='flex'; 
    switch(valor){
        case "1":
            document.getElementById('frame').src='./php/altaClasif.php';
        break;
        case "2":
            document.getElementById('frame').src='./php/altaInsumo.php';
        break;
        case "3":
            document.getElementById('frame').src='./php/concentrado.php';
        break;
    }
}
function pestanaAltas(radio){
    let valor=radio.value;
    opcionesAltas(valor);
}
function clasificacion(){
    let url="./../inc/opciones.php";
    let formData=new FormData();
    formData.append('valor',1);
    fetch(url,{
        method:'POST',
        body: formData,
        mode:'cors'
    }).then(response=>response.json())
    .then(data=>{
        jQuery('#clasifi').append(data);
    })
}

function insumo(select){
    let valor=select.value;
    let url="./../inc/opciones.php";
    let formData=new FormData();
    formData.append('valor',2);
    formData.append('clasif',valor);
    fetch(url,{
        method:'POST',
        body: formData,
        mode:'cors'
    }).then(response=>response.json())
    .then(data=>{
        //document.getElementById('ins').innerHTML=data;
        jQuery('#ins').append(data);
    })
}

function busClasif(){
    let valorClasif=document.getElementById('clasif').value;
    if(valorClasif==''){
        alert('Ingrese Clasificacion');
        return;
    }
    alert(valorClasif);
}

function checka(check,valor){
    switch(valor){
        case 1://activo
            if(check.checked==true){
                document.getElementById('baja').disabled=true;
            }else{
                document.getElementById('baja').disabled=false;
            }
        break;
        case 2://inactivo
            if(check.checked==true){
                document.getElementById('activo').disabled=true;
            }else{
                document.getElementById('activo').disabled=false;
            }
        break;
    }
}
function guarda(){
    if(carrito.length==0){
        alert('No han agregado articulos');
        return;
    }
    let valor="";
    let cantidad=[];
    let insumo=[];
    let empresa=document.getElementById('empresa').value;
    let fechaSol=document.getElementById('fecRec').value;
    let comentarios=document.getElementById('justi').value;
    let files=document.getElementById('adjuntos').files;
    let url="./../inc/operaciones.php";
    let formData=new FormData();
    carrito.forEach(p=>{
        cantidad.push(p.cantidad);
        insumo.push(p.idinsumo);
    })
    for(i=0;i<files.length;i++){
        valor="file"+i;
        formData.append(valor,files[i]);
    }
    formData.append('archivo',i);
    formData.append('empresa',empresa);
    formData.append('fechaSol',fechaSol);
    formData.append('justi',comentarios);
    formData.append('cantidad',cantidad);
    formData.append('insumo',insumo);
    fetch(url,{
        method:'POST',
        body: formData,
        mode:'cors'
    }).then(response=>response.json())
    .then(data=>{
        console.log(data[0]);
        alert(data[0]);
        if(data[1]!=0){
            //que no carge la pagina
            location.href='./../php/solicitud.php';
            emailGuarda(data[2]);
        }
    })
}

function proceso(view){
    let url="./../inc/proceso.php";
    let formData=new FormData();
    formData.append('view',view);
    fetch(url,{
        method:'POST',
        body: formData,
        mode:'cors'
    }).then(response=>response.json())
    .then(data=>{
        //document.getElementById('cuerpo').innerHTML=data;
        jQuery('#cuerpo').append(data);
    });
}
function detalles(folio){
    let url="./../inc/proceso.php";
    let formData=new FormData();
    formData.append('view',3);
    formData.append('folio',folio);
    fetch(url,{
        method:'POST',
        body: formData,
        mode:'cors'
    }).then(response=>response.json())
    .then(data=>{
        //document.getElementById('head').innerHTML=data[0];
        //document.getElementById('cuerpo').innerHTML=data[1];
        //document.getElementById('opciones').innerHTML=data[2];
        jQuery('#head').append(data[0]);
        jQuery('#cuerpo').append(data[1]);
        jQuery('#opciones').append(data[2]);
    });
}

function autoriza(btn,folio){
    let url="./../inc/proceso.php";
    let comen=document.getElementById('comenta').value;
    let formData=new FormData();
    formData.append('view',4);//autorizado jefe
    formData.append('auto',btn);
    formData.append('folio',folio);
    formData.append('comen',comen);
    fetch(url,{
        method:'POST',
        body: formData,
        mode:'cors'
    }).then(response=>response.json())
    .then(data=>{
        location.href='./../php/view.php';
    });
    email(btn);
}
function aprobacion(apro){
    let url="./../inc/proceso.php";
    let formData=new FormData();
    formData.append('view',5);//aprueba rechaza
    formData.append('apro',apro);
    fetch(url,{
        method:'POST',
        body: formData,
        mode:'cors'
    }).then(response=>response.json())
    .then(data=>{
        //document.getElementById('botones').innerHTML=data;
        jQuery('#botones').append(data);
    });
    
}
function rechazaComp(){
    let url="./../inc/proceso.php";
    let rechazo=document.getElementById('rechazo').value;
    let folio=document.getElementById('folio').innerText;
    let datos=["view","rechazo","folio"];
    let valores=[6,rechazo,folio];
    recuperaPhp(url,datos,valores);
    email(7);
}
function recuperaPhp(url,datos,valores){
    let formData=new FormData();
    for(i=0;i<datos.length;i++){
    formData.append(datos[i],valores[i]);
    }
    fetch(url,{
        method:'POST',
        body: formData,
        mode:'cors'
    }).then(response=>response.json())
    .then(data=>{
        pinta(data);
    });
}
function pinta(data){
    alert(data[1]);
    if(data[0]!=0){
        location.href='./../php/view.php';
    }
}

function aceptaComp(){
    let compra=document.getElementById('compra').value;
    if(compra==''){
        alert("Seleccione Compradora");
        return;
    }
    let url="./../inc/proceso.php";
    let folio=document.getElementById('folio').innerText;
    let datos=["view","compra","folio"];
    let valores=[7,compra,folio];
    recuperaPhp(url,datos,valores);
    email(2);
}
function finalizado(){
    let url="./../inc/proceso.php";
    let folio=document.getElementById('folio').innerText;
    let comen=document.getElementById('comenComp').value;
    let datos=["view","comen","folio"];
    let valores=[8,comen,folio];
    recuperaPhp(url,datos,valores);
    email(3);
}
function Vobo(vobo){
    let comen=document.getElementById('comenVobo').value;
    if(vobo==5 && comen==''){
        alert('Debe ingresar comentario del no vobo');
        document.getElementById('comenVobo').focus();
        return;
    }
    let url="./../inc/proceso.php";
    let folio=document.getElementById('folio').innerHTML;
    let datos=["view","comen","folio","vobo"];
    let valores=[9,comen,folio,vobo];
    recuperaPhp(url,datos,valores);
    email(4);
}
function NoVobo(vobo){
    let comen=document.getElementById('comenVobo').value;
    if(vobo==5 && comen==''){
        alert('Debe ingresar comentario del no vobo');
        document.getElementById('comenVobo').focus();
        return;
    }
    let url="./../inc/proceso.php";
    let folio=document.getElementById('folio').innerHTML;
    let datos=["view","comen","folio","vobo"];
    let valores=[9,comen,folio,vobo];
    recuperaPhp(url,datos,valores);
    email(5);
}

function abre(){
    let url="./../inc/proceso.php";
    let foli=document.getElementById('folio').innerHTML;
    let datos=["view","folio"];
    let valores=[10,foli];
    recuperaPhp(url,datos,valores);
}

function email(status){
    let url="./../inc/email.php";
    let foli=document.getElementById('folio').innerHTML;
    let datos=["folio","status"];
    let valores=[foli,status];
    recuperaPhp(url,datos,valores);
}
function emailGuarda(foli){
    let url="./../inc/email.php";
    let datos=["folio","status"];
    let valores=[foli,0];
    recuperaPhp(url,datos,valores);
}
function estimado(){
    let url ="./../inc/proceso.php";
    let foli=document.getElementById('folio').innerHTML;
    let fecha=document.getElementById('fecEst').value;
    let datos=["view","folio","fecha"];
    let valores=[11,foli,fecha];
    recuperaPhp(url,datos,valores);
}
function solicitudDire(){
    let url="./../inc/proceso.php";
    let foli=document.getElementById('folio').innerHTML;
    let files=document.getElementById('cotizacion').files;
    let datos=["view","folio"];
    let valores=[12,foli];
    let i=0;
    for(i=0;i<files.length;i++){
        valor="file"+i;
        datos.push(valor);
        valores.push(files[i]);
    }
    datos.push("archivo");
    valores.push(i);
    recuperaPhp(url,datos,valores);
    email(8);
}
function autorizaDir(status,folio){
    let url="./../inc/proceso.php";
    let comenDir=document.getElementById('comenDir').value;
    let datos=["view","folio","status","comenDir"];
    let valores=[13,folio,status,comenDir];
    recuperaPhp(url,datos,valores);
    email(status);
    document.createElement("tbody");
}