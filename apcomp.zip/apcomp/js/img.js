function carga(){
    let contenido='<tr><td>Hola 2.0</td></tr>';

    let mytable=document.getElementById('tabla');
    let mybody=mytable.createTBody();
    mytable.appendChild(mybody);
    //mytable.append(contenido);
    agregar();
}

function agregar(){
    var fila='<tr class="selected" id="fila"><td></td><td>texto por defecto</td><td></td></tr>';
    jQuery('#tabla').append(fila);
    }