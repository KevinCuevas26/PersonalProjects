<?php 
    session_start();
    if(!isset($_SESSION['id'])){
        header("Location: ../index.php");
    }
    $depto = $_SESSION['depto'];
    require('./../i_database.php');
    $valor=$_POST['valor'];
    //$valor=1;
    $html='';
    switch($valor){
        case 1:
            $sql="SELECT folio,nombre FROM apcomp_Clasificacion WHERE status=1 AND (depto=8 OR depto='$depto')";
            $resultado=mysqli_query($database,$sql);
            $html.='<select name="clasif" id="clasif" onchange="insumo(this)"><option value="">Seleccione...</option>';
            while($extra=mysqli_fetch_array($resultado)){
                $html.='<option value="'.$extra[0].'">'.$extra[1].'</option>';
            }
            $html.='</select>';
        break;
        case 2:
            $clasif=$_POST['clasif'];
            $sql="SELECT folio,insumo FROM apcomp_insumos WHERE clasificacion='$clasif'";
            $resultado=mysqli_query($database,$sql);
            $html.='<select name="insumo" id="insumo"><option value="">Seleccione...</option>';
            while($extra=mysqli_fetch_array($resultado)){
                $html.='<option value="'.$extra[1].'">'.$extra[1].'</option>';
            }
            $html.='</select>';
        break;
        case 3:
            $html='hello world3';
        break;
        default:
            $html='error';
        break;
    }
echo json_encode($html, JSON_UNESCAPED_UNICODE);

?>