<?php 
require 'conexioncorreo.php';
require('./../i_database.php');
$folio=$_POST['folio'];
$sqlOpen="SELECT T0.status,T1.usuario,T1.Nombre,T2.usuario,T0.comendir AS 'comprador',T2.Nombre AS 'nomComp',T3.usuario AS 'autoriza',T3.Nombre AS 'autorizaNom' 
FROM `apcomp_solicitudes` T0 
INNER JOIN usuarios T1 ON T0.solicita=T1.id_user
LEFT OUTER JOIN usuarios T2 ON T0.comprador=T2.id_user
INNER JOIN usuarios T3 ON T0.autoriza=T3.id_user 
WHERE T0.folio='$folio' ";
$resulta=mysqli_query($database,$sqlOpen);
$extra=mysqli_fetch_array($resulta);
$mail->setFrom('covito@cintascove.com');
switch($extra[0]){
    case 0://jefe directo
        $mail->addAddress('mcuevas@cintascove.com','');
        $titulo="Aprobacion de solicitud de compra";
        $contenido="Hola buen dia ".$extra['autorizaNom'];
        $contenido.=".</br>El usuario:".$extra['Nombre']." solicita:</br></br>";
    break;
    case 1://gte de compras
        $mail->addAddress('mcuevas@cintascove.com','');
        $titulo="Nueva Solicitud de Compra";
        $contenido="Hola buen dia Gabriela Corona.";
        $contenido.=".</br>El usuario:".$extra['Nombre']." solicita:</br></br>";
    break;
    case 2://Compradora
        $mail->addAddress('mcuevas@cintascove.com');
        $titulo="Asignacion de ticket de Compra";
        $contenido="Hola buen dia ".$extra['nomComp']."</br>Te asignaron el ticket de compra N° $folio";
        $contenido.=".</br>El usuario:".$extra['Nombre']." solicita:</br></br>";
    break;
    case 3://Finalizado Usuario
        $mail->addAddress('mcuevas@cintascove.com');
        $titulo="Ticket de Compra Finalizado";
        $contenido="Hola buen dia ".$extra['Nombre']."</br>El ticket N°: $folio se finalizo con exito</br></br>Favor de ingresar a la app y dar VOBO o No VOBO";
    break;
    case 4://VOBO de usuario
        $mail->addAddress('mcuevas@cintascove.com');
        $titulo="VOBO de Usuario";
        $contenido="Hola buen dia ".$extra['nomComp']."</br></br>El usuario dio VOBO al ticket N°: $folio";
    break;
    case 5://No VOBO de usuario
        $mail->addAddress('mcuevas@cintascove.com');
        $titulo="No VOBO de Usuario";
        $contenido="Hola buen dia ".$extra['nomComp']."</br></br>El usuario dio No VOBO al ticket N°: $folio</br>Favor de Reatender la solicitud";
    break;
    case 6://rechazada jete inmediato
        $mail->addAddress('mcuevas@cintascove.com');
        $titulo="Solicitud Rechazada";
        $contenido="Hola buen dia ".$extra['Nombre']."</br></br>La solicitud fue rechazada por: ".$extra['autorizaNom'];
    break;
    case 7://rechazada compras
        $mail->addAddress('mcuevas@cintascove.com');
        $titulo="Solicitud rechazada";
        $contenido="Hola buen dia ".$extra['Nombre']."</br></br>La solicitud fue rechazada por el proceso de Compras";
    break;
    case 8://mail a direccion para autorizacion
        $mail->addAddress('mcuevas@cintascove.com');
        $titulo="Autorizacion de Solicitud de Compra";  
        $contenido="Hola buen dia Eduardo Corona </br></br>El Usuario: ".$extra['Nombre']." solicita:</br></br>";  
    break;
    case 9://mail que se envia a compras aprobado
        $mail->addAddress('mcuevas@cintascove.com');
        $titulo="Solicitud aprobada";
        $contenido="Hola buen dia ".$extra['nomComp']."</br></br>Direccion aprobo la solicitud N° ".$folio."";
    break;
    case 10://mail que se envia a compras rechazado
        $mail->addAddress('mcuevas@cintascove.com');
        $titulo="Solicitud rechazada";
        $contenido="Hola buen dia ".$extra['nomComp']."</br></br>Direccion rechazo la solicitud N° ".$folio."</br></br>".$extra['comendir'];
    break;
}
$sqlPartidas="SELECT * FROM apcomp_partidas WHERE foliosol='".$folio."'";
$resultaPartidas=mysqli_query($database,$sqlPartidas);
while($extraPartidas=mysqli_fetch_array($resultaPartidas)){
    $contenido.="</br>".$extraPartidas['cantidad']." ".$extraPartidas['articulo'];
}

$mail->CharSet = 'UTF-8';
$mail->Encoding = 'base64';
$mail->isHTML(true);
$mail->Subject=$titulo;
$mail->Body=$contenido;
$mail->Send();
$html=array(1,"mail enviado");
echo json_encode($html, JSON_UNESCAPED_UNICODE);

?>