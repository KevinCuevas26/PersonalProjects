<?php 
    session_start();
    if(!isset($_SESSION['id'])){
        header("Location: http://intranet/appcove/index.php");
    }
    require('./../i_database.php');
    date_default_timezone_set('America/Mexico_City');
    $fecha=date("Y-m-d H:i:s");
    $iduser = $_SESSION['id'];
    //$iduser=4;
    $html='';
    $view=$_POST['view'];
    switch($view){
        case 1:
            $sqlMuestra="SELECT T0.folio,T1.Nombre,T0.fechasoli,T0.status FROM apcomp_solicitudes T0
            INNER JOIN usuarios T1 ON T0.solicita=T1.id_user ORDER BY T0.folio DESC";

            $resulta=mysqli_query($database,$sqlMuestra);
            while($extra=mysqli_fetch_array($resulta)){
                $html.="<tr>
                    <td>".$extra['folio']."</td>
                    <td>".$extra['Nombre']."</td>
                    <td>".$extra['fechasoli']."</td>
                    <td>".$extra['status']."</td>
                    <td><a href='./detallesticket.php'><svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' style='fill: rgba(0, 0, 0, 1);transform: ;msFilter:;'><path d='m21.426 11.095-17-8A1 1 0 0 0 3.03 4.242l1.212 4.849L12 12l-7.758 2.909-1.212 4.849a.998.998 0 0 0 1.396 1.147l17-8a1 1 0 0 0 0-1.81z'></path></svg></a></td>
                </tr>";
            }
        break;
        case 2: //DETALLES DE LOS TICKETS
            switch($iduser){
                case 16:// gte compras
                    $were=" WHERE T0.status!=0 AND T0.status!=6 ";
                break;
                case 17:// coord compras
                    $were=" WHERE T0.comprador=17 ";
                break;
                case 18:// eje compras
                    $were=" WHERE T0.comprador=18 ";
                break;
                case 19:// direccion 
                    $were=" WHERE T0.solicita=$iduser OR T0.status=8 OR T0.autorizodir=1";
                break;
                default;
                    $were=" WHERE T0.solicita=$iduser OR T0.autoriza=$iduser ";
                break;
            }
            $sqlBusca="SELECT T0.folio,T1.Nombre,T0.fechasoli,T2.descripcion FROM `apcomp_solicitudes` T0 
            INNER JOIN usuarios T1 ON T0.solicita=T1.id_user
            INNER JOIN apcomp_estatus T2 ON T0.status=T2.folio $were ORDER BY T0.folio DESC";
            $resulta=mysqli_query($database,$sqlBusca);
            while($extra=mysqli_fetch_array($resulta)){
                $html.="<tr>
                <td>".$extra['folio']."</td>
                <td>".$extra['Nombre']."</td>
                <td>".$extra['fechasoli']."</td>
                <td>".$extra['descripcion']."</td>
                <td>
                    <a href='./detallesticket.php?folio=".$extra['folio']."'>
                        <svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' style='fill: rgba(0, 0, 0, 1);transform: ;msFilter:;'>
                            <path d='m21.426 11.095-17-8A1 1 0 0 0 3.03 4.242l1.212 4.849L12 12l-7.758 2.909-1.212 4.849a.998.998 0 0 0 1.396 1.147l17-8a1 1 0 0 0 0-1.81z'></path>
                        </svg>
                    </a>
                </td>
                </tr>";
            }
        break;
        case 3://DETALLES COMPLETOS
            $folio=$_POST['folio'];
            $sqlDetalles="SELECT T0.solicita,T0.folio,T1.Nombre,T0.fechasoli,T2.descripcion,T3.nombree,T0.fecreque,T0.fecautocomp,T0.status,T0.autoriza,
            T0.comentarios,T0.comencopras,T0.comentvobo,T0.fecter,T4.Nombre AS 'compradore',T0.comprador,T0.comenin,T0.ruta,T0.fecEst,T0.statusFec,
            T0.rutaCot,T0.comendir,T0.autorizodir FROM `apcomp_solicitudes` T0 
            INNER JOIN usuarios T1 ON T0.solicita=T1.id_user
            INNER JOIN apcomp_estatus T2 ON T0.status=T2.folio 
            INNER JOIN empresa T3 ON T0.empresa=T3.folio
            LEFT OUTER JOIN usuarios T4 ON T0.comprador=T4.id_user
            WHERE T0.folio='$folio'";
            $resulta=mysqli_query($database,$sqlDetalles);
            $extra=mysqli_fetch_array($resulta);
            $opciones="";
            $head="
            <tr>
                <td>N° de ticket:</td><td id='folio'>".$extra['folio']."</td>
                <td>Solicita:</td><td>".$extra['Nombre']."</td>
            </tr>
            <tr>
                <td>Empresa:</td><td>".$extra['nombree']."</td>
                <td>Fecha de solicitud:</td><td>".$extra['fechasoli']."</td>
            </tr>
            <tr>

                <td>Fecha requerida:</td><td>".$extra['fecreque']."</td>";
            if($iduser==17 || $iduser==18){
                $head.="<td>Fecha asignacion ticket:</td><td>".$extra['fecautocomp']."</td>";
            }else{
                $head.="<td>Estatus del ticket:</td><td>".$extra['descripcion']."</td>";
            }
            $head.="</tr>
            <tr>
            <td>Justificacion: </td>
            <td colspan='3'>".$extra['comentarios']."</td>
            </tr>";
            if($extra['statusFec']==1 && $iduser!=16 && $iduser!=17 && $iduser!=18){
                $head.="<tr>
                    <td colspan='2'>Fecha estimada de entrega:</td>
                    <td>".$extra['fecEst']."</td>
                </tr>";
            }    
            $sqlCuerpo="SELECT * FROM apcomp_partidas WHERE foliosol=$folio";
            $resultado=mysqli_query($database,$sqlCuerpo);
            $body="<tr><td colspan='2'>Cantidad</td><td colspan='2'>Item</td></tr>";
            while($extraC=mysqli_fetch_array($resultado)){
                $body.="
                <tr>
                <td colspan='2'>".$extraC['cantidad']."</td>
                <td colspan='2'>".$extraC['articulo']."</td>
                </tr>";
            }
            if($extra['ruta']!=0 || $extra['rutaCot']!=0){
                $array=explode(";",$extra['ruta']);
                $arrayCot=explode(";",$extra['rutaCot']);
                if(count($array)<count($arrayCot)){
                    $recorrido=count(($arrayCot));
                }else{
                    $recorrido=count($array);
                }
                for($i=0;$i<$recorrido;$i++){
                    $name=explode("/",$array[$i]);
                    $extension=explode(".",$name['4']);
                    $body.="<tr>
                    <td> ";
                        if($extension['1']=='pdf'){
                            $body.="<a href='".$array[$i]."' download='".$name['4']."'><button type='button' class='btnimagen' data-toggle='modal' >
                            <img id='image' src='./../img/pdf.svg' width='50px' height='50px'/></button></a></td>";
                        }
                        else if($extension['1']=='doc' || $extension['1']=='docx'){
                            $body.="<a href='".$array[$i]."' download><button type='button' class='btnimagen' data-toggle='modal' >
                            <img id='image' src='./../img/doc.svg' width='50px' height='50px'/></button></a></td>";
                        }
                        else if($extension['1']=='xlsx' || $extension['1']=='xls' || $extension['1']=='xlsm'){
                            $body.="<a href='".$array[$i]."' download='".$name['4']."'><button type='button' class='btnimagen' data-toggle='modal' >
                            <img id='image' src='./../img/xls.svg' width='50px' height='50px'/></button></a></td>";
                        }else{
                            if(file_exists($array[$i])){
                                $body.="<button type='button' class='btnimagen' data-toggle='modal' data-target='#exampleModal$i'>
                                <img id='image' src='".$array[$i]."' width='50px' height='50px'/></button></td>";
                            }else{
                                $body.="<a href='".$array[$i]."' download='".$name['4']."'><button type='button' class='btnimagen' data-toggle='modal' >
                                <img id='image' src='./../img/404.svg' width='50px' height='50px'/></button></a></td>";
                            }
                        }
                        $body.="<td colspan='2'><a href='".$array[$i]."' download='".$name['4']."'><button class='buttonDownload'>Descargar Archivo</button></a></td>";
                        
                        if($i<count($arrayCot)){
                            if(file_exists($arrayCot[$i])){
                                $f=$i+1;
                                $body.="<td><a href='".$arrayCot[$i]."' download='cotizacion".$folio."-".$f."'><button class='buttonDownload'>Descargar Cotizacion</button></a></td>";
                            }
                        }else{
                            $body.="<td>&nbsp;</td>";
                        }
                    $body.="</tr>";
                    $body.="
                <div class='modal fade' id='exampleModal$i' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>
                <div class='modal-dialog' role='document'>
                    <div class='modal-content'>
                        <div class='modal-body' style='text-align:center'>
                            <img id='image' src='".$array[$i]." ' width='350px' height='350px'
                                alt='Click on button' />
                        </div>
                    <div class='modal-footer'>
                        <button type='button' class='btn btn-secondary' data-dismiss='modal'>Cerrar</button>
                    </div>
                </div>
                </div>
                </div>";
                }
            }
            if($extra['status']==0 && $iduser==$extra['autoriza']){
                $opciones.="<tr>
                    <td>Comentarios</td>
                    <td><textarea id='comenta' name='comenta'></textarea></td>
                </tr>
                <tr>
                    <td><button class='boton' onclick='autoriza(6,$folio)'>No Autorizado</button></td>
                    <td><button class='boton' onclick='autoriza(1,$folio)'>Autorizado</button></td>
                </tr>";
            }

            if($iduser==16 && $extra['status']==1){
                $opciones.="<tr>
                <td><button class='boton' onclick='aprobacion(0)'>Rechazar Solicitud</button></td>
                <td><button class='boton' onclick='aprobacion(1)'>Aceptar Solicitud</button></td>
                </tr>";
            }
            switch($extra['status']){
                case 2:
                    if($iduser==16 || $iduser==$extra['comprador']){
                        $statusFec="";
                        $fechaEst=$extra['fecEst'];
                        if($extra['statusFec']==''){
                            $statusFec="<button class='boton' onclick='estimado()'>Aceptar</button>";
                            $fechaEst="</br><input type='date' name='fecEst' id='fecEst'/>";
                        }
                        $opciones.="<tr>
                            <td>
                            <div class='form__group field'>
                            <textarea class='form__field' placeholder='Comentarios'id='comenComp' name='comenComp'></textarea>
                            <label for='name' class='form__label'>Comentarios</label>
                            </div></td>
                            <td>Fecha estimada: $fechaEst </td>
                        </tr>
                        <tr>
                        <td colspan='2'>Ingrese Cotizacion: <input type='file' id='cotizacion' name='cotizacion' multiple/></td>
                        </tr>
                        <tr style='height:100px'>
                            <td colspan='2'><button class='boton' onclick='solicitudDire()'>Direccion</button>
                            <button class='boton' onclick='finalizado()'>Finalizar Ticket</button>
                            $statusFec</td>
                        </tr>";
                    }
                break;    
                case 3:
                    $opciones.="<tr>
                        <td colspan='2'>Comentarios Compras: ".$extra['comencopras']."</td>
                    </tr>";
                    if($iduser==$extra['solicita']){
                        $opciones.="<tr>
                            <td colspan='2'><div class='form__group field'>
                            <textarea class='form__field' placeholder='Comentarios'id='comenVobo' name='comenVobo'></textarea>
                            <label for='name' class='form__label'>Comentarios</label>
                            </div></td>
                        </tr>
                        <tr style='height:100px'>
                            <td><button class='boton' onclick='NoVobo(5)'>No VoBO</button></td>
                            <td><button class='boton' onclick='Vobo(4)'>VOBO</button></td>
                        </tr>";
                    }
                    if($extra['autorizodir']==1 && $iduser==$extra['comprador'] || $iduser==16){
                        $opciones.="<tr><td>Comentarios Direccion:
                        ".$extra['comendir']."</td>
                        </tr>";
                    }
                break;
                case 4:
                    $opciones.="<tr>
                        <td>Comentarios del usuario: ".$extra['comentvobo']."</td>
                    </tr>";
                    if($iduser==16 || $iduser==$extra['comprador']){
                        $opciones.="<tr>
                            <td>Comprador: ".$extra['compradore']."</td>
                        </tr>";
                    }
                    if($extra['autorizodir']==1 && $iduser==$extra['comprador'] || $iduser==16){
                        $opciones.="<tr><td>Comentarios Direccion:
                        ".$extra['comendir']."</td>
                        </tr>";
                    }
                break;
                case 5: 
                    $opciones.="<tr>
                        <td>Comentarios del no Vobo: ".$extra['comentvobo']."</td>
                    </tr>";
                    if($iduser==16 || $iduser==$extra['comprador']){
                        $opciones.="<tr>
                            <td>Comprador: ".$extra['compradore']."</td>
                        </tr>
                        <tr style='height:100px'>
                            <td><button class='boton' onclick='abre()'>Reabrir Ticket</button></td>
                        </tr>";
                    }
                    if($extra['autorizodir']==1 && $iduser==$extra['comprador'] || $iduser==16){
                        $opciones.="<tr><td>Comentarios Direccion:
                        ".$extra['comendir']."</td>
                        </tr>";
                    }
                break;
                case 6:    
                    $comentarios="<td>Comentarios jefe Inmediato</td><td>".$extra['comenin']."</td>";
                    $opciones.="<tr>".$comentarios."</tr>";
                break;
                case 7:
                    $comentarios="<td>Comentarios gte Compras</td><td>".$extra['comencopras']."</td>";
                    $opciones.="<tr>".$comentarios."</tr>";
                break;
                case 8:
                    if($iduser==19){
                        $opciones.="<tr>
                        <td colspan='2'>
                            <div class='form__group field'>
                            <textarea class='form__field' placeholder='Comentarios'id='comenDir' name='comenDir'></textarea>
                            <label for='name' class='form__label'>Comentarioss</label>
                            </div></td>
                        </tr>
                        <tr>
                        <td><button class='boton' onclick='autorizaDir(9,$folio)'>Autorizado</button></td>
                        <td><button class='boton' onclick='autorizaDir(10,$folio)'>No Autorizado</button></td>
                    </tr>";
                    }
                break;
                case 9:
                    if($iduser==16 || $iduser==$extra['comprador']){
                        $opciones.="
                        <tr>
                            <td colspan='2'>Comentarios Direccion</td>
                        </tr>
                        <tr>
                            <td colspan='2'>".$extra['comendir']."</td>
                        </tr>";
                        $statusFec="";
                        $fechaEst=$extra['fecEst'];
                        if($extra['statusFec']==''){
                            $statusFec="<button class='boton' onclick='estimado()'>Aceptar</button>";
                            $fechaEst="</br><input type='date' name='fecEst' id='fecEst'/>";
                        }
                        $opciones.="<tr>
                            <td>
                            <div class='form__group field'>
                            <textarea class='form__field' placeholder='Comentarios'id='comenComp' name='comenComp'></textarea>
                            <label for='name' class='form__label'>Comentarios</label>
                            </div></td>
                            <td>Fecha estimada: $fechaEst </td>
                        </tr>
                        <tr style='height:100px'>
                            <td colspan='2'>
                            <button class='boton' onclick='finalizado()'>Finalizar Ticket</button>
                            $statusFec</td>
                        </tr>";
                    }else if($iduser==19){
                        $opciones.="
                        <tr>
                            <td>Comentarios Direccion</td>
                        </tr>
                        <tr>
                            <td>".$extra['comendir']."</td>
                        </tr>";
                    }
                break;
                case 10:
                        $opciones.="
                        <tr>
                            <td colspan='2'>Comentarios Direccion</td>
                        </tr>
                        <tr>
                            <td colspan='2'>".$extra['comendir']."</td>
                        </tr>";
                    
                break;
            }

            $html=array($head,$body,$opciones);
        break;
        case 4://autoriza jefe inmediato
            $autoriza=$_POST['auto'];
            $folio=$_POST['folio'];
            $comen=$_POST['comen'];
            $sqlAuto="UPDATE apcomp_solicitudes SET status='$autoriza', autorizoin='$autoriza', fecautoin='$fecha',comenin='$comen' 
            WHERE folio='$folio'";
            mysqli_query($database,$sqlAuto);
        break;
        case 5://muestra detalles de aprobacion o rechazo 
            $apro=$_POST['apro'];
            if($apro==0){//rechazado
                $html="<tr colspan='2'>
                    <td>Comentarios del rechazo</td>
                </tr>
                <tr>
                    <td><textarea id='rechazo' name='rechazo'></textarea></td>
                </tr>
                <tr colspan='2'>
                    <td><button class='boton' onclick='rechazaComp()'>Aceptar</button></td>
                </tr>";
            }else{
                $html="<tr style='height:50px'><td>&nbsp;</td></tr>
                <tr>
                    <td>Asignar Compradora:</td>
                    <td>
                        <select id='compra' name='compra'>
                            <option value=''>Seleccione...</option>
                            <option value='16'>Gabriela Corona Barrueta</option>
                            <option value='17'>Ayamain Matamoros Lozano</option>
                            <option value='18'>Leticia Garcia Lopez</option>
                        </select>
                    </td>
                </tr>
                <tr style='height:70px'>
                    <td colspan='2'><button class='boton' onclick='aceptaComp()'>Aceptar</button></td>
                </tr>";
            }
        break;
        case 6://solicitud rechazada compras
            $rechazo=$_POST['rechazo'];
            $folio=$_POST['folio'];
            $sqlRechazo="UPDATE apcomp_solicitudes SET status='7',autorizocomp='0', fecautocomp='$fecha', comencopras='$rechazo' 
            WHERE folio='$folio'";
            mysqli_query($database,$sqlRechazo);
            $html=array(1,"Solicitud Rechazada");
        break;
        case 7://solicitud aceptada compras
            $compra=$_POST['compra'];
            $folio=$_POST['folio'];
            $sqlAcepta="UPDATE apcomp_solicitudes SET status='2', autorizocomp='1', fecautocomp='$fecha',comprador='$compra'
            WHERE folio='$folio' ";
            try{
            mysqli_query($database,$sqlAcepta);
                $html=array(1,'Ticket Asignado con exito');
            }catch(Exception $ex){
                $error='Error '.mysqli_error($database);
                $html=array(0,$error);
            }
        break;
        case 8://ticket finalizado
            $folio=$_POST['folio'];
            $comen=$_POST['comen'];
            $sqlFinaliza="UPDATE apcomp_solicitudes SET status='3',fecter='$fecha',comencopras='$comen' 
            WHERE folio='$folio'";
            try{
                mysqli_query($database,$sqlFinaliza);
                $html=array(1,'Ticket Finalizado con exito');
            }catch(Exception $ex){
                $error='Error '.mysqli_error($database);
                $html=array(0,$error);
            }
        break;
        case 9;//Vobo No Vobo
            $folio=$_POST['folio'];
            $comen=$_POST['comen'];
            $vobo=$_POST['vobo'];
            $sqlVobo="UPDATE apcomp_solicitudes SET status='$vobo',fecvobo='$fecha',comentvobo='$comen'
            WHERE folio='$folio'";
            try{
                mysqli_query($database,$sqlVobo);
                $html=array(1,"VoBo con exito");
            }catch(Exception $ex){
                $error='Error:'.mysqli_error($database);
                $html=array(0,$error);
            }
        break;
        case 10://open compra
            $folio=$_POST['folio'];
            $sqlOpen="UPDATE apcomp_solicitudes SET status='2' WHERE folio='$folio'";
            try{
                mysqli_query($database,$sqlOpen);
                $html=array(1,"Ticket reabierto con exito");
            }catch(Exception $ex){
                $error='Error:'.mysqli_error($database);
                $html=array(0,$error);
            }
        break;
        case 11://ingresa fecha tentativa de entrega
            $folio=$_POST['folio'];
            $fecEst=$_POST['fecha'];
            $sqlFec="UPDATE apcomp_solicitudes SET fecEst='$fecEst', statusFec='1' WHERE folio='$folio'";
            try{
                mysqli_query($database,$sqlFec);
                $html=array(1,"Fecha modificada con exito");
            }catch(Exception $ex){
                $error='Error:'.mysqli_error($database);
                $html=array(0,$error);
            }
        break;
        case 12://Manda solicitud a direccion para aprobacion
            $folio=$_POST['folio'];
            $valores=$_POST['archivo'];
            $url="0";
            $rutaCot="";
            if(!empty($_FILES)){
                for($i=0;$i<$valores;$i++){
                    $final='./../archivos/'.$folio.'/cotizacion/';
                    if(!file_exists($final)){
                        mkdir($final,0777,true);
                    }
                    $archivo="file".$i;
                    $nombreA=$_FILES[$archivo]['name'];
                    $temp=$_FILES[$archivo]['tmp_name'];
                    $final.=$nombreA;
                    if($i==0){
                        $url=$final;
                    }else{
                        $url.=";".$final;
                    }
                    move_uploaded_file($temp,$final);
                }
            $rutaCot=" ,rutaCot='$url'";
            }

            $sqlDir="UPDATE apcomp_solicitudes SET status='8' $rutaCot WHERE folio='$folio'";
            try{
                mysqli_query($database,$sqlDir);
                $html=array(1,"Fecha modificada con exito");
            }catch(Exception $ex){
                $error='Error:'.mysqli_error($database);
                $html=array(0,$error);
            }
        break;
        case 13://Autorizacion por direccion
            $folio=$_POST['folio'];
            $status=$_POST['status'];
            $comendir=$_POST['comenDir'];
            $sqlDir="UPDATE apcomp_solicitudes SET status='$status', autorizodir=1, fecautodir='$fecha', comendir='$comendir' 
            WHERE folio='$folio'";
            try{
                mysqli_query($database,$sqlDir);
                $html=array(1,"Datos guardados con Exito");
            }catch(Exception $ex){
                $error='Error:'.mysqli_error($database);
                $html=array(0,$error);
            }
        break;
    }

    
    echo json_encode($html, JSON_UNESCAPED_UNICODE);
?>