<?php 
try{
    session_start();
    if(!isset($_SESSION['id'])){
        header("Location: http://intranet/appcove/index.php");
    }
    $iduser = $_SESSION['id'];
    $nombre = $_SESSION['nombre'];
    //$iduser=4;
    require('./../i_database.php');
    date_default_timezone_set('America/Mexico_City');
    $fecha=date("Y-m-d H:i:s");
    $empresa=$_POST['empresa'];
    $fechaSol=$_POST['fechaSol'];
    $justi=$_POST['justi'];

    $cantidad=$_POST['cantidad'];
    $insumo=$_POST['insumo'];
    $arrCant=explode(',',$cantidad);
    $arrIns=explode(',',$insumo);
    $sql="SELECT T0.autorizacomp,T1.Nombre,T1.usuario FROM usuarios T0
    INNER JOIN usuarios T1 ON T0.autorizacomp=T1.id_user
    WHERE T0.id_user='$iduser'";
    $res=mysqli_query($database,$sql);
    $autoriza=mysqli_fetch_array($res);
    $status=0;
    if($autoriza[0]==$iduser){
        $status=1;
    }
    
    $sqlSolicita="INSERT INTO apcomp_solicitudes(`folio`,`solicita`,`empresa`,`fecreque`,`comentarios`,`fechasoli`,`status`,`autoriza`)
    VALUES (null,'$iduser','$empresa','$fechaSol','$justi','$fecha','$status','".$autoriza[0]."')";
    mysqli_query($database,$sqlSolicita);
    $folioQuery=mysqli_insert_id($database);
    $contador=count($arrCant);
    for($i=0;$i<$contador;$i++){
       $sqlPartidas="INSERT INTO `apcomp_partidas`(`folio`, `foliosol`, `cantidad`, `articulo`) 
       VALUES (null,'$folioQuery','".$arrCant[$i]."','".$arrIns[$i]."')";
        mysqli_query($database,$sqlPartidas);
    }
    $valores=$_POST['archivo'];
    $url="0";
    if(!empty($_FILES)){
        for($i=0;$i<$valores;$i++){
            $final='./../archivos/'.$folioQuery.'/adjuntos/';
            if(!file_exists($final)){
                mkdir($final,0777,true);
            }
            $archivo="file".$i;
            $nombreA=$_FILES[$archivo]['name'];
            $temp=$_FILES[$archivo]['tmp_name'];
            $final.=$nombreA;
            if($i==0){
                $url=$final;
            }else{
                $url.=";".$final;
            }
            move_uploaded_file($temp,$final);
        }
        $sqlUpt="UPDATE apcomp_solicitudes SET `ruta`='$url' WHERE `folio`='$folioQuery'";
                mysqli_query($database,$sqlUpt);
    }
    
    
    $html=array('Guardado con exito',1,$folioQuery);
    echo json_encode($html, JSON_UNESCAPED_UNICODE);

}catch(Exception $ex){
    $error='Error '.$ex;
    $html=array($error,0);
    echo json_encode($html, JSON_UNESCAPED_UNICODE);

}
    

?>